# Changelog — Recommendation Patch

## [2026-05-02] Recommendation Engine Insertion

### Added

- `recommendation_engine.py`
  - Track-S / Track-L Top-N recommendation scanner.
  - Multi-confirmation validation checks.
  - Markdown and JSON recommendation reports.
  - Synthetic demo mode for offline validation.
- `main.py` CLI options:
  - `--recommend`
  - `--universe`
  - `--track {S,L,BOTH}`
  - `--top`
  - `--synthetic`
  - `--output-dir`
- `main.py::test_recommendation_engine_synthetic`
- `RECOMMENDATION_ENGINE.md`
- `DOC_REVIEW_AND_INSERTION.md`

### Changed

- Root CLI can now run either the original single-ticker prediction pipeline or the new universe-wide recommendation scanner.
- SETUP.md now includes Recommendation Engine commands.

### Safety

- No broker API added.
- No order execution added.
- No credentials added.
- All recommendation results include `screening_output_only=True`.
- `ELIGIBLE_RECOMMENDATION` and `ACCUMULATE_RECOMMENDATION` require manual review.

### Verified

| Check | Command | Result |
|---|---|---|
| Tests | `python -m pytest -q main.py` | 5 passed |
| Recommendation demo | `python main.py --recommend --synthetic --universe SYNTH-A,SYNTH-B,SYNTH-C --top 3` | Markdown/JSON generated |
