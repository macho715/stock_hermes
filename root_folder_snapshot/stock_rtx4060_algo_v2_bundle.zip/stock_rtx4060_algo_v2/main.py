"""
stock_rtx4060 algorithm-v2 CLI.

Examples
--------
python main.py --test
python main.py --recommend --synthetic --universe SYNTH-A,SYNTH-B,SYNTH-C --track BOTH --top 5
python main.py --benchmark --synthetic --benchmark-rows 1200
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from backtester import BacktestConfig, Backtester, KellyCriterion
from ensemble_model import EnsemblePredictor, ModelConfig
from feature_engine import TechnicalIndicators
from hw_profile import print_hw_summary, probe_environment
from recommendation_engine import make_synthetic_ohlcv, run_recommendation_cli


def _make_dummy_ohlcv(n: int = 360, seed: int = 42) -> pd.DataFrame:
    return make_synthetic_ohlcv(n=n, seed=seed)


# ────────────────────────────────────────────────────────────────
# Tests usable by pytest and `python main.py --test`
# ────────────────────────────────────────────────────────────────


def test_feature_engine_basic() -> None:
    df = _make_dummy_ohlcv(360)
    feat = TechnicalIndicators(df).build_all(horizon=5)
    assert len(feat) > 0
    assert "target_direction" in feat.columns
    assert feat["target_direction"].isin([0, 1]).all()
    assert feat.isnull().sum().sum() == 0


def test_feature_engine_edge() -> None:
    try:
        TechnicalIndicators(pd.DataFrame({"Close": [1, 2, 3]}))
        raise AssertionError("예외 미발생")
    except ValueError:
        pass
    tiny = TechnicalIndicators(_make_dummy_ohlcv(45)).build_all(horizon=5)
    assert isinstance(tiny, pd.DataFrame)


def test_backtester_basic() -> None:
    rng = np.random.default_rng(0)
    n = 220
    index = pd.bdate_range("2025-01-01", periods=n)
    prices = pd.Series(np.cumprod(1 + rng.normal(0.0004, 0.01, n)) * 100, index=index)
    signals = pd.Series(rng.uniform(0, 1, n), index=index)
    result = Backtester(BacktestConfig(initial_capital=100_000)).run(prices, signals)
    assert result["final_capital"] > 0
    assert result["max_drawdown_pct"] >= 0
    assert "sortino_ratio" in result
    assert "profit_factor" in result


def test_kelly_criterion() -> None:
    kelly = KellyCriterion(fraction=0.25)
    assert 0.01 <= kelly.kelly_pct() <= 0.25
    for _ in range(30):
        kelly.update(0.05)
    for _ in range(15):
        kelly.update(-0.03)
    assert 0.01 <= kelly.kelly_pct() <= 0.25


def test_recommendation_engine_synthetic() -> None:
    from recommendation_engine import RecommendationConfig, RecommendationEngine

    cfg = RecommendationConfig(
        universe=["SYNTH-A"],
        track="S",
        top_n=1,
        synthetic=True,
        model_kind="logistic",
        xgb_splits=2,
        min_rows=260,
    )
    results = RecommendationEngine(cfg).run()
    assert len(results) == 1
    result = results[0]
    assert result.screening_output_only
    assert result.confirmations_total >= 8
    assert result.risk_reward >= 0
    assert result.stop < result.entry or result.verdict == "RED_DATA_OR_MODEL_ERROR"


def test_ensemble_leak_safe_cv() -> None:
    df = _make_dummy_ohlcv(420, seed=7)
    feat = TechnicalIndicators(df).build_all(horizon=10)
    model = EnsemblePredictor(ModelConfig(horizon=10, n_splits=3, gap=10, model_kind="logistic"))
    cv = model.fit(feat)
    assert len(cv) >= 2
    assert model.oof_probabilities_ is not None
    assert model.oof_probabilities_.notna().mean() < 1.0
    pred = model.predict(feat.drop(columns=["target_direction", "target_return"]))
    assert 0.0 <= float(pred["direction_prob"]) <= 1.0


def run_self_tests() -> int:
    tests = [
        test_feature_engine_basic,
        test_feature_engine_edge,
        test_backtester_basic,
        test_kelly_criterion,
        test_recommendation_engine_synthetic,
        test_ensemble_leak_safe_cv,
    ]
    failures: list[str] = []
    start = time.perf_counter()
    for test in tests:
        try:
            test()
            print(f"PASS {test.__name__}")
        except Exception as exc:  # pragma: no cover - CLI diagnostic
            failures.append(f"{test.__name__}: {exc}")
            print(f"FAIL {test.__name__}: {exc}")
    elapsed = time.perf_counter() - start
    print(f"\nself-test: {len(tests) - len(failures)}/{len(tests)} passed in {elapsed:.2f}s")
    if failures:
        print("\n".join(failures))
        return 1
    return 0


# ────────────────────────────────────────────────────────────────
# Pipeline and benchmark
# ────────────────────────────────────────────────────────────────


def _download_or_synthetic(ticker: str, period: str, synthetic: bool) -> tuple[pd.DataFrame, str]:
    if synthetic:
        return make_synthetic_ohlcv(seed=sum(ord(ch) for ch in ticker)), "synthetic_demo_data"
    try:
        import yfinance as yf  # type: ignore

        df = yf.download(ticker, period=period, auto_adjust=True, progress=False, threads=False)
        if isinstance(df.columns, pd.MultiIndex):
            df.columns = df.columns.droplevel(-1)
        rename = {c: str(c).capitalize() for c in df.columns if str(c).lower() in {"open", "high", "low", "close", "volume"}}
        df = df.rename(columns=rename)
        required = ["Open", "High", "Low", "Close", "Volume"]
        if df.empty or any(c not in df.columns for c in required):
            raise RuntimeError("empty or malformed yfinance response")
        return df.loc[:, required].dropna(), "yfinance"
    except Exception as exc:
        print(f"WARN yfinance 실패; synthetic fallback 사용: {exc}")
        return make_synthetic_ohlcv(seed=sum(ord(ch) for ch in ticker)), "synthetic_fallback"


def run_pipeline(args: argparse.Namespace) -> dict[str, Any]:
    print_hw_summary()
    print(f"\nPipeline: ticker={args.ticker}, horizon={args.horizon}, period={args.period}")
    df, source = _download_or_synthetic(args.ticker, args.period, args.synthetic)
    print(f"[1/5] data source={source}, rows={len(df)}")

    feat = TechnicalIndicators(df).build_all(horizon=args.horizon)
    if feat.empty:
        raise RuntimeError("feature frame is empty")
    feat_cols = [c for c in feat.columns if c not in {"target_direction", "target_return"}]
    print(f"[2/5] features rows={len(feat)}, cols={len(feat_cols)}")

    model_cfg = ModelConfig(
        horizon=args.horizon,
        n_splits=args.splits,
        gap=args.cv_gap if args.cv_gap is not None else args.horizon,
        model_kind=args.model_kind,
        xgb_device=args.xgb_device,
        use_lstm=args.use_lstm,
    )
    model = EnsemblePredictor(model_cfg)
    print("[3/5] fitting leak-safe walk-forward model")
    cv = model.fit(feat)
    cv_df = pd.DataFrame(cv)
    print(f"CV accuracy={cv_df['accuracy'].mean():.3f}, auc={cv_df['auc'].mean():.3f}, gap={cv_df['gap'].iloc[0]}")

    print("[4/5] latest prediction")
    pred = model.predict(feat.loc[:, feat_cols])
    print(json.dumps(pred, ensure_ascii=False, indent=2))

    print("[5/5] OOF backtest")
    prices = df.loc[feat.index, "Close"]
    signals = model.oof_probabilities_.fillna(0.5) if model.oof_probabilities_ is not None else pd.Series(0.5, index=feat.index)
    bt = Backtester(BacktestConfig(stop_loss_pct=0.04, take_profit_pct=0.10, threshold_buy=0.56)).run(prices, signals)
    print(json.dumps({k: v for k, v in bt.items() if k not in {"portfolio_values", "trades"}}, ensure_ascii=False, indent=2))
    return {"source": source, "cv": cv, "prediction": pred, "backtest": bt}


def run_benchmark(args: argparse.Namespace) -> dict[str, Any]:
    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    rows = int(args.benchmark_rows)
    universe = [item.strip().upper() for item in args.universe.split(",") if item.strip()]
    if not universe:
        universe = ["SYNTH-A", "SYNTH-B", "SYNTH-C"]

    start = time.perf_counter()
    df = make_synthetic_ohlcv(n=rows, seed=123)
    t0 = time.perf_counter()
    feat = TechnicalIndicators(df).build_all(horizon=args.horizon)
    t_feature = time.perf_counter() - t0

    t1 = time.perf_counter()
    model = EnsemblePredictor(ModelConfig(horizon=args.horizon, n_splits=args.splits, gap=args.horizon, model_kind="logistic"))
    cv = model.fit(feat)
    t_model = time.perf_counter() - t1

    t2 = time.perf_counter()
    signals = model.oof_probabilities_.fillna(0.5) if model.oof_probabilities_ is not None else pd.Series(0.5, index=feat.index)
    bt = Backtester(BacktestConfig()).run(df.loc[feat.index, "Close"], signals)
    t_backtest = time.perf_counter() - t2

    # Recommendation smoke benchmark on a small synthetic universe.
    t3 = time.perf_counter()
    from recommendation_engine import RecommendationConfig, RecommendationEngine

    rec_cfg = RecommendationConfig(universe=universe[:1], synthetic=True, track="S", top_n=1, model_kind="logistic", xgb_splits=2)
    recs = RecommendationEngine(rec_cfg).run()
    t_recommend = time.perf_counter() - t3

    total = time.perf_counter() - start
    result = {
        "rows": rows,
        "feature_rows": int(len(feat)),
        "feature_cols": int(len([c for c in feat.columns if c not in {"target_direction", "target_return"}])),
        "feature_seconds": round(t_feature, 4),
        "model_seconds": round(t_model, 4),
        "backtest_seconds": round(t_backtest, 4),
        "recommend_seconds": round(t_recommend, 4),
        "total_seconds": round(total, 4),
        "cv_accuracy_mean": round(float(pd.DataFrame(cv)["accuracy"].mean()), 4),
        "cv_auc_mean": round(float(pd.DataFrame(cv)["auc"].mean()), 4),
        "backtest_summary": {k: v for k, v in bt.items() if k not in {"portfolio_values", "trades"}},
        "recommendation_count": len(recs),
        "environment": probe_environment(),
    }
    ts = time.strftime("%Y%m%d_%H%M%S")
    json_path = out_dir / f"benchmark_algo_v2_{ts}.json"
    md_path = out_dir / f"benchmark_algo_v2_{ts}.md"
    json_path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    md_path.write_text(_render_benchmark_markdown(result), encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    print(f"Benchmark saved: {md_path}")
    return result


def _render_benchmark_markdown(result: dict[str, Any]) -> str:
    return "\n".join(
        [
            "# Algorithm v2 Benchmark",
            "",
            f"Rows: {result['rows']}",
            f"Feature rows: {result['feature_rows']}",
            f"Feature cols: {result['feature_cols']}",
            "",
            "| Stage | Seconds |",
            "|---|---:|",
            f"| Feature engineering | {result['feature_seconds']:.4f} |",
            f"| Model walk-forward | {result['model_seconds']:.4f} |",
            f"| Backtest | {result['backtest_seconds']:.4f} |",
            f"| Recommendation smoke | {result['recommend_seconds']:.4f} |",
            f"| Total | {result['total_seconds']:.4f} |",
            "",
            f"CV accuracy mean: {result['cv_accuracy_mean']:.4f}",
            f"CV AUC mean: {result['cv_auc_mean']:.4f}",
            "",
            "Backtest summary:",
            "```json",
            json.dumps(result["backtest_summary"], ensure_ascii=False, indent=2),
            "```",
        ]
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="stock_rtx4060 algorithm-v2 pipeline")
    parser.add_argument("--ticker", default="AAPL")
    parser.add_argument("--horizon", type=int, default=5)
    parser.add_argument("--period", default="5y")
    parser.add_argument("--synthetic", action="store_true")
    parser.add_argument("--model-kind", choices=["auto", "xgb", "logistic"], default="logistic")
    parser.add_argument("--xgb-device", choices=["cpu", "cuda"], default="cpu")
    parser.add_argument("--splits", type=int, default=3)
    parser.add_argument("--cv-gap", type=int, default=None)
    parser.add_argument("--use-lstm", action="store_true")
    parser.add_argument("--test", action="store_true")
    parser.add_argument("--benchmark", action="store_true")
    parser.add_argument("--benchmark-rows", type=int, default=800)
    parser.add_argument("--recommend", action="store_true")
    parser.add_argument("--universe", default="AAPL,MSFT,NVDA,AMD,AVGO,GOOGL,AMZN,META,TSLA,QQQ,SPY")
    parser.add_argument("--track", choices=["S", "L", "BOTH"], default="BOTH")
    parser.add_argument("--top", type=int, default=5)
    parser.add_argument("--output-dir", default="recommendation_reports")
    return parser


if __name__ == "__main__":
    args = build_parser().parse_args()
    if args.test:
        raise SystemExit(run_self_tests())
    if args.recommend:
        raise SystemExit(run_recommendation_cli(args))
    if args.benchmark:
        run_benchmark(args)
    else:
        run_pipeline(args)
