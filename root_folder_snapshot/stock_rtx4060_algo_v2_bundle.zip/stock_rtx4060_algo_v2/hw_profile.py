"""Hardware profile helpers for i5-13500HX + RTX 4060 Laptop workflows."""
from __future__ import annotations

import os
import platform
import subprocess
from dataclasses import dataclass, asdict
from typing import Any

CPU_LOGICAL_CORES = 20
CPU_PHYSICAL_P_CORES = 6
CPU_EFFECTIVE_WORKERS = 16
CPU_INTRAOP_THREADS = 6
CPU_INTEROP_THREADS = 4

for key, value in {
    "OMP_NUM_THREADS": CPU_INTRAOP_THREADS,
    "MKL_NUM_THREADS": CPU_INTRAOP_THREADS,
    "OPENBLAS_NUM_THREADS": CPU_INTRAOP_THREADS,
    "NUMEXPR_NUM_THREADS": CPU_EFFECTIVE_WORKERS,
    "TF_CPP_MIN_LOG_LEVEL": 3,
    "CUDA_DEVICE_ORDER": "PCI_BUS_ID",
}.items():
    os.environ.setdefault(key, str(value))


@dataclass(frozen=True)
class HardwareProfile:
    cpu_model: str = "Intel Core i5-13500HX"
    logical_cores: int = CPU_LOGICAL_CORES
    effective_workers: int = CPU_EFFECTIVE_WORKERS
    gpu_model: str = "NVIDIA GeForce RTX 4060 Laptop"
    vram_gb: int = 8
    preferred_xgb_device: str = "cuda"
    preferred_tf_vram_mb: int = 6144
    os_name: str = platform.platform()


def probe_environment() -> dict[str, Any]:
    """Return a non-fatal runtime environment probe."""
    result: dict[str, Any] = {"profile": asdict(HardwareProfile())}
    try:
        import xgboost as xgb  # type: ignore

        result["xgboost_version"] = xgb.__version__
    except Exception as exc:
        result["xgboost_error"] = str(exc)
    try:
        import tensorflow as tf  # type: ignore

        gpus = tf.config.list_physical_devices("GPU")
        result["tensorflow_gpus"] = [getattr(gpu, "name", str(gpu)) for gpu in gpus]
    except Exception as exc:
        result["tensorflow_error"] = str(exc)
    try:
        proc = subprocess.run(["nvidia-smi", "--query-gpu=name,memory.total", "--format=csv,noheader"], capture_output=True, text=True, timeout=5)
        result["nvidia_smi"] = proc.stdout.strip() if proc.returncode == 0 else proc.stderr.strip()
    except Exception as exc:
        result["nvidia_smi_error"] = str(exc)
    return result


def configure_tensorflow(vram_limit_mb: int = 6144, mixed_precision: bool = True) -> dict[str, Any]:
    """Configure TensorFlow GPU if available; returns status without raising."""
    status = {"gpu_available": False, "vram_limit_mb": vram_limit_mb, "mixed_precision": False, "device": "cpu"}
    try:
        import tensorflow as tf  # type: ignore

        gpus = tf.config.list_physical_devices("GPU")
        if not gpus:
            return status
        tf.config.set_logical_device_configuration(gpus[0], [tf.config.LogicalDeviceConfiguration(memory_limit=vram_limit_mb)])
        if mixed_precision:
            from tensorflow.keras import mixed_precision as mp  # type: ignore

            mp.set_global_policy("mixed_float16")
            status["mixed_precision"] = True
        tf.config.threading.set_intra_op_parallelism_threads(CPU_INTRAOP_THREADS)
        tf.config.threading.set_inter_op_parallelism_threads(CPU_INTEROP_THREADS)
        status.update({"gpu_available": True, "device": "cuda:0", "gpu_name": getattr(gpus[0], "name", "GPU")})
    except Exception as exc:
        status["error"] = str(exc)
    return status


HW_PROFILE = asdict(HardwareProfile())


def print_hw_summary() -> None:
    profile = HardwareProfile()
    print("\n" + "=" * 60)
    print("  stock_rtx4060 hardware profile")
    print("=" * 60)
    print(f"  CPU: {profile.cpu_model} ({profile.logical_cores} logical cores)")
    print(f"  GPU target: {profile.gpu_model} {profile.vram_gb}GB")
    print(f"  Workers: {profile.effective_workers}")
    print(f"  Preferred XGBoost device: {profile.preferred_xgb_device}")
    print("=" * 60)
