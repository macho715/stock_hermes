"""Compatibility wrapper for stock_rtx4060 CLI."""

from stock_rtx4060.main import main

if __name__ == "__main__":
    raise SystemExit(main())
