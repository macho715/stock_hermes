"""Compatibility wrapper. Use stock_rtx4060.backtester instead."""
from stock_rtx4060.backtester import *  # noqa: F401,F403
