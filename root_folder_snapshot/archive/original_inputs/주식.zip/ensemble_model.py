"""Compatibility wrapper. Use stock_rtx4060.ensemble_model instead."""
from stock_rtx4060.ensemble_model import *  # noqa: F401,F403
