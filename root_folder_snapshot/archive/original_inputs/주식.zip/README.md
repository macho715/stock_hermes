# stock_rtx4060 patched investment OS

Purpose: Windows i5-13500HX + RTX 4060 환경에서 Track-S 단타, Track-L 장기, Risk Gate, GPU 검증/벤치마크, 리포트 생성을 한 번에 실행하는 Python 패키지입니다.

This is a decision-support tool. It does not submit broker orders, does not recommend a specific security, and does not bypass the risk gates.

## Quick start

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
python main.py self-test
python main.py demo --workspace .\demo_workspace
python main.py benchmark --rows 1500 --repeats 3 --include-gpu --output-dir .\reports
```

## Core commands

```bash
python main.py self-test
python main.py env --output reports/runtime_status.json
python main.py benchmark --rows 1500 --repeats 3 --include-gpu
python main.py report --ticker AAPL --csv data/aapl.csv --capital 100000
python main.py predict --ticker AAPL --period 3y --prefer-gpu --lite
python stock_investment_os.py demo --workspace demo_workspace
```

## Outputs

- `daily_brief_*.md`
- `risk_dashboard_*.md`
- `track_l_thesis_*.md`
- `monthly_scorecard_*.md`
- `benchmark_*.md/json`
- `runtime_status.json`
- `decision_journal.csv`

## Patch summary

- Replaced hard-coded Windows TensorFlow GPU assumption with an explicit GPU validation gate.
- Added XGBoost CUDA smoke-test path using `device="cuda"` when requested.
- Added deterministic NumPy logistic fallback so tests/reports still work on CPU-only machines.
- Added benchmark harness: feature generation, model training, optional GPU request, and backtest timing.
- Added Track-S / Track-L risk gates, monthly stop, position sizing, report generation, journal logging.
- Preserved top-level compatibility wrappers: `main.py`, `stock_investment_os.py`, `hw_profile.py`, `feature_engine.py`, `ensemble_model.py`, `backtester.py`.
