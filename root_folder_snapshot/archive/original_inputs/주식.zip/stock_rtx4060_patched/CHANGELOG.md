# Changelog

## 2026-05-02 patched

- Added explicit environment validation logs for `nvidia-smi`, TensorFlow GPU probe and XGBoost probe.
- Added benchmark runner with CSV/JSON/Markdown output.
- Patched CLI to support `--test`, `--benchmark`, `--backend`, `--offline-fixture`, `--strict-gpu`.
- Added offline deterministic OHLCV fixture so tests and reports run without network data.
- Replaced unconditional XGBoost import with backend-specific optional import.
- Made TensorFlow/LSTM optional because modern TensorFlow GPU on Windows Native requires WSL2.
- Added report engine for Daily Brief, Risk Dashboard, Track-L Thesis, Monthly Scorecard and Journal.
- Added TimeSeriesSplit walk-forward validation with horizon-sized gap.
