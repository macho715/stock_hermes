python .\main.py --benchmark --offline-fixture --rows 900 --repeats 3 --backend sklearn --output-dir .\reports\benchmark
