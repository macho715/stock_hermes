"""Backtesting with fractional Kelly sizing and hard risk gates."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np
import pandas as pd


@dataclass(frozen=True)
class BacktestConfig:
    initial_capital: float = 100_000.0
    transaction_cost: float = 0.001
    slippage: float = 0.0005
    max_position_pct: float = 0.20
    kelly_fraction: float = 0.25
    threshold_buy: float = 0.56
    threshold_sell: float = 0.46
    stop_loss_pct: float = 0.04
    take_profit_pct: float = 0.10
    monthly_halt_loss_pct: float = 0.05


class KellySizer:
    def __init__(self, fraction: float = 0.25) -> None:
        self.fraction = fraction
        self.wins: list[float] = []
        self.losses: list[float] = []

    def update(self, pnl_pct: float) -> None:
        if pnl_pct > 0:
            self.wins.append(pnl_pct)
        elif pnl_pct < 0:
            self.losses.append(abs(pnl_pct))

    def size_fraction(self, *, fallback: float = 0.06, max_position_pct: float = 0.20) -> float:
        if len(self.wins) < 3 or len(self.losses) < 3:
            return min(fallback, max_position_pct)
        win_rate = len(self.wins) / (len(self.wins) + len(self.losses))
        avg_win = float(np.mean(self.wins))
        avg_loss = float(np.mean(self.losses)) or 1e-9
        payoff = avg_win / avg_loss
        raw = win_rate - (1 - win_rate) / max(payoff, 1e-9)
        return float(np.clip(raw * self.fraction, 0.01, max_position_pct))


class Backtester:
    def __init__(self, config: BacktestConfig | None = None) -> None:
        self.config = config or BacktestConfig()

    def run(self, prices: pd.Series, probabilities: pd.Series) -> dict[str, Any]:
        if len(prices) != len(probabilities):
            raise ValueError("prices and probabilities length mismatch")
        prices = prices.astype(float).reset_index(drop=True)
        probabilities = probabilities.astype(float).reset_index(drop=True)
        cash = float(self.config.initial_capital)
        quantity = 0.0
        entry_price = 0.0
        equity_curve: list[float] = []
        trades: list[dict[str, Any]] = []
        kelly = KellySizer(self.config.kelly_fraction)
        current_month = None
        month_start_equity = cash
        halt_this_month = False

        for i, (price, prob) in enumerate(zip(prices, probabilities, strict=True)):
            mark_value = cash + quantity * price
            month_key = i // 21
            if current_month is None or month_key != current_month:
                current_month = month_key
                month_start_equity = mark_value
                halt_this_month = False
            month_return = mark_value / month_start_equity - 1.0
            if month_return <= -self.config.monthly_halt_loss_pct:
                halt_this_month = True

            if quantity > 0:
                pnl_pct = price / entry_price - 1.0
                should_exit = (
                    prob <= self.config.threshold_sell
                    or pnl_pct <= -self.config.stop_loss_pct
                    or pnl_pct >= self.config.take_profit_pct
                    or halt_this_month
                )
                if should_exit:
                    proceeds = quantity * price * (1.0 - self.config.transaction_cost - self.config.slippage)
                    pnl_value = proceeds - quantity * entry_price
                    cash += proceeds
                    trades.append(
                        {
                            "bar": i,
                            "side": "SELL",
                            "price": round(float(price), 4),
                            "probability": round(float(prob), 5),
                            "pnl_pct": round(float(pnl_pct), 5),
                            "pnl_value": round(float(pnl_value), 2),
                            "reason": "risk_gate_or_signal",
                        }
                    )
                    kelly.update(pnl_pct)
                    quantity = 0.0
                    entry_price = 0.0
            if quantity == 0 and not halt_this_month and prob >= self.config.threshold_buy:
                size_pct = kelly.size_fraction(max_position_pct=self.config.max_position_pct)
                budget = cash * size_pct
                qty = budget / (price * (1.0 + self.config.transaction_cost + self.config.slippage))
                if qty > 0:
                    cost = qty * price * (1.0 + self.config.transaction_cost + self.config.slippage)
                    cash -= cost
                    quantity = qty
                    entry_price = price
                    trades.append(
                        {
                            "bar": i,
                            "side": "BUY",
                            "price": round(float(price), 4),
                            "probability": round(float(prob), 5),
                            "position_pct": round(float(size_pct), 5),
                            "reason": "probability_gate",
                        }
                    )
            equity_curve.append(cash + quantity * price)

        equity = pd.Series(equity_curve, dtype=float)
        returns = equity.pct_change().fillna(0.0)
        drawdown = equity / equity.cummax() - 1.0
        sell_trades = [trade for trade in trades if trade["side"] == "SELL"]
        wins = [t for t in sell_trades if t.get("pnl_pct", 0) > 0]
        final_equity = float(equity.iloc[-1]) if not equity.empty else self.config.initial_capital
        return {
            "initial_capital": round(self.config.initial_capital, 2),
            "final_equity": round(final_equity, 2),
            "total_return_pct": round((final_equity / self.config.initial_capital - 1.0) * 100.0, 4),
            "max_drawdown_pct": round(float(drawdown.min()) * 100.0, 4),
            "sharpe_like": round(float(returns.mean() / (returns.std() + 1e-9) * np.sqrt(252)), 4),
            "trade_count": len(sell_trades),
            "win_rate_pct": round((len(wins) / len(sell_trades) * 100.0) if sell_trades else 0.0, 4),
            "open_risk_pct": round((quantity * entry_price * self.config.stop_loss_pct / max(final_equity, 1e-9)) * 100.0, 4),
            "exposure_pct": round((quantity * prices.iloc[-1] / max(final_equity, 1e-9)) * 100.0, 4),
            "monthly_halt_loss_pct": self.config.monthly_halt_loss_pct * 100.0,
            "equity_curve": [round(float(v), 2) for v in equity.tail(20)],
            "trades": trades[-50:],
        }
