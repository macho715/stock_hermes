"""Vectorized OHLCV feature engineering for Track-S and model input."""
from __future__ import annotations

from dataclasses import dataclass
import numpy as np
import pandas as pd

OHLCV_COLUMNS = ("Open", "High", "Low", "Close", "Volume")


def normalize_ohlcv(df: pd.DataFrame) -> pd.DataFrame:
    """Normalize yfinance/CSV OHLCV frames to Open/High/Low/Close/Volume."""
    if isinstance(df.columns, pd.MultiIndex):
        df = df.copy()
        if set(OHLCV_COLUMNS).intersection(set(map(str, df.columns.get_level_values(0)))):
            df.columns = [str(c[0]) for c in df.columns]
        else:
            df.columns = [str(c[-1]) for c in df.columns]
    rename: dict[str, str] = {}
    aliases = {
        "open": "Open",
        "high": "High",
        "low": "Low",
        "close": "Close",
        "adj close": "Close",
        "adj_close": "Close",
        "volume": "Volume",
    }
    for col in df.columns:
        key = str(col).strip().lower().replace("_", " ")
        if key in aliases:
            rename[col] = aliases[key]
    out = df.rename(columns=rename).copy()
    missing = set(OHLCV_COLUMNS) - set(out.columns)
    if missing:
        raise ValueError(f"필수 OHLCV 컬럼 누락: {sorted(missing)}")
    out = out.loc[:, list(OHLCV_COLUMNS)]
    for col in OHLCV_COLUMNS:
        out[col] = pd.to_numeric(out[col], errors="coerce")
    out = out.dropna(subset=list(OHLCV_COLUMNS))
    if not out.index.is_monotonic_increasing:
        out = out.sort_index()
    return out


@dataclass(slots=True)
class FeatureBuildConfig:
    horizon: int = 5
    include_price_columns: bool = False
    min_rows: int = 220


class TechnicalIndicators:
    """Technical indicator builder with look-ahead controls."""

    def __init__(self, df: pd.DataFrame):
        self.df = normalize_ohlcv(df)

    def sma(self, period: int) -> pd.Series:
        return self.df["Close"].rolling(period, min_periods=period).mean()

    def ema(self, period: int) -> pd.Series:
        return self.df["Close"].ewm(span=period, adjust=False).mean()

    def macd(self) -> tuple[pd.Series, pd.Series, pd.Series]:
        line = self.ema(12) - self.ema(26)
        signal = line.ewm(span=9, adjust=False).mean()
        return line, signal, line - signal

    def true_range(self) -> pd.Series:
        high, low, close = self.df["High"], self.df["Low"], self.df["Close"]
        return pd.concat([high - low, (high - close.shift(1)).abs(), (low - close.shift(1)).abs()], axis=1).max(axis=1)

    def atr(self, period: int = 14) -> pd.Series:
        return self.true_range().rolling(period, min_periods=period).mean()

    def adx(self, period: int = 14) -> pd.Series:
        high, low = self.df["High"], self.df["Low"]
        atr = self.atr(period)
        up_move = high.diff()
        down_move = -low.diff()
        plus_dm = up_move.where((up_move > down_move) & (up_move > 0), 0.0)
        minus_dm = down_move.where((down_move > up_move) & (down_move > 0), 0.0)
        plus_di = 100 * plus_dm.rolling(period, min_periods=period).mean() / atr
        minus_di = 100 * minus_dm.rolling(period, min_periods=period).mean() / atr
        dx = 100 * (plus_di - minus_di).abs() / (plus_di + minus_di).replace(0, np.nan)
        return dx.rolling(period, min_periods=period).mean()

    def rsi(self, period: int = 14) -> pd.Series:
        delta = self.df["Close"].diff()
        gain = delta.clip(lower=0).ewm(alpha=1 / period, min_periods=period, adjust=False).mean()
        loss = (-delta.clip(upper=0)).ewm(alpha=1 / period, min_periods=period, adjust=False).mean()
        rs = gain / loss.replace(0, np.nan)
        return 100 - (100 / (1 + rs))

    def stochastic(self, k: int = 14, d: int = 3) -> tuple[pd.Series, pd.Series]:
        low_min = self.df["Low"].rolling(k, min_periods=k).min()
        high_max = self.df["High"].rolling(k, min_periods=k).max()
        pct_k = 100 * (self.df["Close"] - low_min) / (high_max - low_min).replace(0, np.nan)
        return pct_k, pct_k.rolling(d, min_periods=d).mean()

    def williams_r(self, period: int = 14) -> pd.Series:
        high_max = self.df["High"].rolling(period, min_periods=period).max()
        low_min = self.df["Low"].rolling(period, min_periods=period).min()
        return -100 * (high_max - self.df["Close"]) / (high_max - low_min).replace(0, np.nan)

    def cci(self, period: int = 20) -> pd.Series:
        typical = (self.df["High"] + self.df["Low"] + self.df["Close"]) / 3
        ma = typical.rolling(period, min_periods=period).mean()
        mad = typical.rolling(period, min_periods=period).apply(lambda values: float(np.mean(np.abs(values - np.mean(values)))), raw=True)
        return (typical - ma) / (0.015 * mad.replace(0, np.nan))

    def bollinger_bands(self, period: int = 20, k: float = 2.0) -> tuple[pd.Series, pd.Series, pd.Series, pd.Series, pd.Series]:
        mid = self.sma(period)
        std = self.df["Close"].rolling(period, min_periods=period).std()
        upper = mid + k * std
        lower = mid - k * std
        width = (upper - lower) / mid.replace(0, np.nan)
        pct_b = (self.df["Close"] - lower) / (upper - lower).replace(0, np.nan)
        return upper, mid, lower, width, pct_b

    def historical_volatility(self, period: int = 20) -> pd.Series:
        log_ret = np.log(self.df["Close"] / self.df["Close"].shift(1))
        return log_ret.rolling(period, min_periods=period).std() * np.sqrt(252) * 100

    def obv(self) -> pd.Series:
        direction = np.sign(self.df["Close"].diff()).fillna(0)
        return (direction * self.df["Volume"]).cumsum()

    def vwap(self, period: int = 20) -> pd.Series:
        typical = (self.df["High"] + self.df["Low"] + self.df["Close"]) / 3
        denom = self.df["Volume"].rolling(period, min_periods=period).sum().replace(0, np.nan)
        return (typical * self.df["Volume"]).rolling(period, min_periods=period).sum() / denom

    def mfi(self, period: int = 14) -> pd.Series:
        typical = (self.df["High"] + self.df["Low"] + self.df["Close"]) / 3
        money_flow = typical * self.df["Volume"]
        pos = money_flow.where(typical > typical.shift(1), 0).rolling(period, min_periods=period).sum()
        neg = money_flow.where(typical < typical.shift(1), 0).rolling(period, min_periods=period).sum()
        mfr = pos / neg.replace(0, np.nan)
        return 100 - (100 / (1 + mfr))

    def build_all(self, horizon: int = 5, include_price_columns: bool = False) -> pd.DataFrame:
        f = self.df.copy()
        close = f["Close"]
        f["return_1d"] = close.pct_change(1)
        f["return_5d"] = close.pct_change(5)
        f["return_20d"] = close.pct_change(20)
        f["log_return_1d"] = np.log(close / close.shift(1))
        for period in (5, 10, 20, 50, 200):
            f[f"sma_ratio_{period}"] = close / self.sma(period) - 1
        for period in (9, 21):
            f[f"ema_ratio_{period}"] = close / self.ema(period) - 1
        f["macd"], f["macd_signal"], f["macd_hist"] = self.macd()
        f["adx_14"] = self.adx(14)
        f["rsi_14"] = self.rsi(14)
        f["rsi_7"] = self.rsi(7)
        f["stoch_k"], f["stoch_d"] = self.stochastic()
        f["williams_r"] = self.williams_r()
        f["cci_20"] = self.cci()
        f["roc_10"] = close.pct_change(10) * 100
        f["bb_upper"], f["bb_mid"], f["bb_lower"], f["bb_width"], f["bb_pct"] = self.bollinger_bands()
        f["atr_14"] = self.atr(14)
        f["atr_pct"] = f["atr_14"] / close.replace(0, np.nan)
        f["hist_vol_20"] = self.historical_volatility()
        f["obv"] = self.obv()
        f["vwap_ratio"] = close / self.vwap(20) - 1
        f["mfi_14"] = self.mfi(14)
        f["volume_ratio"] = f["Volume"] / f["Volume"].rolling(20, min_periods=20).mean().replace(0, np.nan)
        f["high_20"] = f["High"].rolling(20, min_periods=20).max()
        f["is_20d_breakout"] = (close >= f["high_20"].shift(1)).astype(float)
        f["reclaim_5d"] = ((close > close.rolling(5, min_periods=5).mean()) & (close > f["High"].shift(1))).astype(float)
        f["market_regime_score"] = np.select([f["sma_ratio_50"] > 0.02, f["sma_ratio_50"] < -0.02], [1.0, -1.0], default=0.0)
        future_return = close.shift(-horizon) / close - 1
        f["target_direction"] = (future_return > 0).astype(int)
        f["target_return"] = future_return
        drop_cols = (["bb_upper", "bb_mid", "bb_lower", "high_20"] if include_price_columns else list(OHLCV_COLUMNS) + ["bb_upper", "bb_mid", "bb_lower", "high_20"])
        f = f.drop(columns=drop_cols, errors="ignore")
        f = f.replace([np.inf, -np.inf], np.nan).dropna()
        return f[f["target_return"].notna()]


def build_features(df: pd.DataFrame, horizon: int = 5, include_price_columns: bool = False) -> pd.DataFrame:
    return TechnicalIndicators(df).build_all(horizon=horizon, include_price_columns=include_price_columns)
