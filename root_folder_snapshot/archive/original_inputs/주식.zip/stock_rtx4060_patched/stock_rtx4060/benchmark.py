"""Benchmark harness for patched stock_rtx4060 scripts."""
from __future__ import annotations
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path
import json, time
from typing import Any
import pandas as pd
from .backtester import Backtester
from .data_loader import make_dummy_ohlcv
from .ensemble_model import EnsemblePredictor, ModelConfig
from .feature_engine import build_features
from .hw_profile import get_hardware_profile

@dataclass(frozen=True)
class BenchItem:
    name: str
    seconds: float
    rows: int
    notes: str
    def to_dict(self) -> dict[str, Any]: return asdict(self)

def _timeit(name: str, fn, rows: int, notes: str) -> tuple[Any, BenchItem]:
    start = time.perf_counter(); result = fn(); elapsed = time.perf_counter() - start
    return result, BenchItem(name, round(elapsed, 4), rows, notes)

def run_benchmark(*, rows: int = 1200, include_model: bool = False, prefer_gpu: bool = False, use_lstm: bool = False) -> dict[str, Any]:
    profile = get_hardware_profile().to_dict(); items: list[BenchItem] = []
    df, item = _timeit("make_dummy_ohlcv", lambda: make_dummy_ohlcv(rows), rows, "offline deterministic data"); items.append(item)
    features, item = _timeit("feature_engine", lambda: build_features(df, horizon=5, include_price_columns=True), len(df), "vectorized pandas/numpy"); items.append(item)
    prices = features["Close"] if "Close" in features.columns else df["Close"].iloc[-len(features):].reset_index(drop=True)
    signals = (0.50 + 0.20 * features["sma_ratio_20"].clip(-0.2, 0.2) + 0.10 * features["macd_hist"].rank(pct=True).fillna(0.5) + 0.10 * (features["volume_ratio"].fillna(1).clip(0, 2) / 2)).clip(0, 1)
    backtest, item = _timeit("backtester", lambda: Backtester().run(prices.reset_index(drop=True), signals.reset_index(drop=True)), len(features), "Track-S stop/TP/time-stop simulation"); items.append(item)
    model_summary: dict[str, Any] = {"enabled": include_model}
    if include_model:
        def fit_model() -> dict[str, Any]:
            clean = features.drop(columns=["Open", "High", "Low", "Close", "Volume"], errors="ignore")
            model = EnsemblePredictor(ModelConfig(prefer_gpu=prefer_gpu, use_lstm=use_lstm, n_splits=3))
            cv = model.fit(clean); x, _ = model._split_xy(clean); pred = model.predict(x)
            return {"cv": cv, "prediction": pred}
        model_summary, item = _timeit("ensemble_model", fit_model, len(features), f"prefer_gpu={prefer_gpu}, use_lstm={use_lstm}"); items.append(item)
    return {"generated_at": datetime.now().isoformat(timespec="seconds"), "hardware_profile": profile, "benchmarks": [i.to_dict() for i in items], "model_summary": model_summary, "backtest_summary": {k: v for k, v in backtest.items() if k not in {"portfolio_values", "trades"}}}

def write_benchmark_report(result: dict[str, Any], out_dir: str | Path) -> tuple[Path, Path]:
    out_dir = Path(out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    json_path = out_dir / "benchmark_result.json"; md_path = out_dir / "benchmark_report.md"
    json_path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    df = pd.DataFrame(result.get("benchmarks", [])); bench_table = df.to_markdown(index=False) if not df.empty else "_No benchmark rows._"
    backtest = pd.DataFrame([result.get("backtest_summary", {})]).to_markdown(index=False)
    profile = result.get("hardware_profile", {})
    md = f"""# Benchmark Report — stock_rtx4060 patched

Generated: `{result.get('generated_at')}`

## Hardware Probe

```json
{json.dumps(profile, ensure_ascii=False, indent=2)}
```

## Timings

{bench_table}

## Backtest Summary

{backtest}

## 2026 Technical Baseline Applied

| Area | Patch decision |
|---|---|
| TensorFlow GPU | Native Windows CUDA is not assumed. WSL2/Linux path is preferred; native Windows falls back to CPU. |
| XGBoost GPU | Uses `device='cuda'` + `tree_method='hist'` only when GPU is requested/detected, with CPU fallback. |
| pandas I/O | CSV loader attempts `engine='pyarrow'` / `dtype_backend='pyarrow'`, then falls back to standard pandas. |
| Backtesting | Uses internal event simulator to avoid AGPL coupling while cross-checking vectorized backtest practices. |
| yfinance | Treated as research/education data source; CSV path remains first-class for reproducibility. |

## Re-run on target RTX 4060

```powershell
python -m stock_rtx4060.benchmark --rows 3000 --model --prefer-gpu --out ./benchmark_out
```
"""
    md_path.write_text(md, encoding="utf-8"); return json_path, md_path

def main() -> None:
    import argparse
    parser = argparse.ArgumentParser(description="stock_rtx4060 benchmark harness")
    parser.add_argument("--rows", type=int, default=1200); parser.add_argument("--model", action="store_true"); parser.add_argument("--prefer-gpu", action="store_true"); parser.add_argument("--use-lstm", action="store_true"); parser.add_argument("--out", default="./benchmark_out")
    args = parser.parse_args(); result = run_benchmark(rows=args.rows, include_model=args.model, prefer_gpu=args.prefer_gpu, use_lstm=args.use_lstm); json_path, md_path = write_benchmark_report(result, args.out)
    print(f"benchmark_json={json_path}"); print(f"benchmark_report={md_path}")
if __name__ == "__main__": main()
