"""Markdown reporting for Daily Brief, Risk Dashboard, Journal and Scorecard."""
from __future__ import annotations
from dataclasses import dataclass
from datetime import date, datetime
import json
from pathlib import Path
from typing import Any
import pandas as pd
from .rules import RiskPolicy, TrackSDecision

@dataclass(frozen=True)
class ReportBundle:
    daily_brief: Path
    risk_dashboard: Path
    monthly_scorecard: Path
    track_l_thesis: Path
    benchmark: Path | None = None

def _fmt_pct(value: float | int | None) -> str:
    return "N/A" if value is None else f"{float(value):.2f}%"

def _table(rows: list[dict[str, Any]]) -> str:
    if not rows: return "_No rows._\n"
    return pd.DataFrame(rows).to_markdown(index=False) + "\n"

def write_daily_brief(reports_dir: str | Path, *, ticker: str, model_signal: dict[str, Any], decision: TrackSDecision, backtest: dict[str, Any], asof: date | None = None) -> Path:
    asof = asof or date.today(); reports_dir = Path(reports_dir); reports_dir.mkdir(parents=True, exist_ok=True); path = reports_dir / f"daily_brief_{asof.isoformat()}.md"
    content = f"""# Daily Brief — {asof.isoformat()}

## Scope

- Ticker: `{ticker}`
- Purpose: decision support only; no automated order execution.
- Model signal: **{model_signal.get('signal', 'N/A')}**
- Direction probability: {float(model_signal.get('direction_prob', 0.5)):.3f}
- XGB backend: `{model_signal.get('xgb_backend', 'N/A')}`
- LSTM backend: `{model_signal.get('lstm_backend', 'N/A')}`

## Track-S Candidate

{_table([decision.to_dict()])}

## Backtest Snapshot

{_table([{k: v for k, v in backtest.items() if k not in {'portfolio_values', 'trades'}}])}

## Notes

- `GREEN` means rule-qualified candidate for manual review; it is not a buy order.
- `ZERO` means execution is blocked by risk policy.
"""
    path.write_text(content, encoding="utf-8"); return path

def write_risk_dashboard(reports_dir: str | Path, *, policy: RiskPolicy, decision: TrackSDecision, backtest: dict[str, Any], asof: date | None = None) -> Path:
    asof = asof or date.today(); reports_dir = Path(reports_dir); reports_dir.mkdir(parents=True, exist_ok=True); alloc = policy.allocation; path = reports_dir / f"risk_dashboard_{asof.isoformat()}.md"
    rows = [{"Track": "Track-S", "Allocation": f"{policy.track_s_pct:.2%}", "Value": round(alloc.track_s, 2), "Max Loss Rule": "monthly -5% stop"}, {"Track": "Track-L", "Allocation": f"{policy.track_l_pct:.2%}", "Value": round(alloc.track_l, 2), "Max Loss Rule": "quarterly -12% review"}, {"Track": "Cash", "Allocation": f"{policy.cash_pct:.2%}", "Value": round(alloc.cash, 2), "Max Loss Rule": "not for Track-S rescue"}]
    gates = [{"Check": "Track-S gate", "Value": decision.gate.value}, {"Check": "Track-S score", "Value": decision.score}, {"Check": "Risk/reward", "Value": decision.risk_reward}, {"Check": "Backtest MDD", "Value": _fmt_pct(backtest.get("max_drawdown_pct"))}, {"Check": "Backtest Sharpe", "Value": backtest.get("sharpe_ratio")}]
    content = f"""# Risk Dashboard — {asof.isoformat()}

## Allocation

{_table(rows)}

## Gate Checks

{_table(gates)}

## ZERO Rules

- No stop price → ZERO
- Track-S monthly PnL ≤ -5.00% → ZERO
- Track-S open risk > 2.00% → ZERO
- Automatic buy/order placement → ZERO
- Excessive margin/options/0DTE use → ZERO
"""
    path.write_text(content, encoding="utf-8"); return path

def write_monthly_scorecard(reports_dir: str | Path, *, backtest: dict[str, Any], asof: date | None = None) -> Path:
    asof = asof or date.today(); reports_dir = Path(reports_dir); reports_dir.mkdir(parents=True, exist_ok=True); path = reports_dir / f"monthly_scorecard_{asof.isoformat()}.md"
    content = f"""# Monthly Scorecard — {asof.isoformat()}

## Performance

{_table([{k: v for k, v in backtest.items() if k not in {'portfolio_values', 'trades'}}])}

## Last 10 Trade Events

{_table(backtest.get('trades', [])[-10:])}

## Review Questions

1. Did Track-S losses stay isolated from Track-L capital?
2. Were all entries logged before execution?
3. Did any RED/ZERO gate get overridden?
"""
    path.write_text(content, encoding="utf-8"); return path

def write_track_l_thesis(reports_dir: str | Path, *, policy: RiskPolicy, asof: date | None = None) -> Path:
    asof = asof or date.today(); reports_dir = Path(reports_dir); reports_dir.mkdir(parents=True, exist_ok=True); path = reports_dir / f"track_l_thesis_{asof.isoformat()}.md"; alloc = policy.allocation
    rows = [{"Bucket": "Core Global Equity ETF", "Allocation": "40% of Track-L", "Value": round(alloc.track_l * 0.40, 2)}, {"Bucket": "Quality / Dividend / Cashflow", "Allocation": "20% of Track-L", "Value": round(alloc.track_l * 0.20, 2)}, {"Bucket": "AI Infrastructure / Semiconductors / Power", "Allocation": "15% of Track-L", "Value": round(alloc.track_l * 0.15, 2)}, {"Bucket": "Commodity / Energy / Materials", "Allocation": "10% of Track-L", "Value": round(alloc.track_l * 0.10, 2)}, {"Bucket": "Bonds / T-bills / Money Market", "Allocation": "10% of Track-L", "Value": round(alloc.track_l * 0.10, 2)}, {"Bucket": "Opportunistic Cash", "Allocation": "5% of Track-L", "Value": round(alloc.track_l * 0.05, 2)}]
    content = f"""# Track-L Thesis — {asof.isoformat()}

## Portfolio Structure

{_table(rows)}

## Entry Rule

- New Track-L candidate requires score ≥ 80.00.
- Initial buy is 30.00% of target weight; remaining allocation via DCA or drawdown-add rules.
- Single non-ETF name above 12.00% triggers rebalance review.
"""
    path.write_text(content, encoding="utf-8"); return path

def append_journal(workspace: str | Path, entry: dict[str, Any]) -> Path:
    workspace = Path(workspace); journal_dir = workspace / "journal"; journal_dir.mkdir(parents=True, exist_ok=True); path = journal_dir / "journal.csv"
    payload = {"timestamp": datetime.now().isoformat(timespec="seconds"), **entry}; df = pd.DataFrame([payload])
    df.to_csv(path, mode="a" if path.exists() else "w", header=not path.exists(), index=False); return path

def write_json(path: str | Path, data: dict[str, Any]) -> Path:
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True); path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8"); return path

def write_report_bundle(workspace: str | Path, *, ticker: str, policy: RiskPolicy, model_signal: dict[str, Any], decision: TrackSDecision, backtest: dict[str, Any], asof: date | None = None) -> ReportBundle:
    reports_dir = Path(workspace) / "reports"
    return ReportBundle(write_daily_brief(reports_dir, ticker=ticker, model_signal=model_signal, decision=decision, backtest=backtest, asof=asof), write_risk_dashboard(reports_dir, policy=policy, decision=decision, backtest=backtest, asof=asof), write_monthly_scorecard(reports_dir, backtest=backtest, asof=asof), write_track_l_thesis(reports_dir, policy=policy, asof=asof))
