"""Main CLI for patched stock_rtx4060 investment OS."""
from __future__ import annotations
import argparse, sys
from pathlib import Path
from typing import Any
import pandas as pd
from .backtester import Backtester, BacktestConfig
from .benchmark import run_benchmark, write_benchmark_report
from .data_loader import load_ohlcv, write_sample_csv
from .ensemble_model import EnsemblePredictor, ModelConfig
from .feature_engine import TechnicalIndicators, build_features
from .hw_profile import configure_tensorflow, print_hw_summary
from .reporting import append_journal, write_report_bundle
from .rules import Gate, RiskPolicy, make_track_s_decision, score_track_l

def self_test() -> int:
    from .data_loader import make_dummy_ohlcv
    df = make_dummy_ohlcv(360); feat = TechnicalIndicators(df).build_all(horizon=5, include_price_columns=True)
    assert len(feat) > 50; assert feat["target_direction"].isin([0, 1]).all(); assert feat.isna().sum().sum() == 0
    decision = make_track_s_decision("SELFTEST", feat.iloc[-1].to_dict(), entry=float(feat["Close"].iloc[-1]), catalyst=True)
    assert decision.quantity >= 0; assert decision.gate in {Gate.GREEN, Gate.AMBER, Gate.RED, Gate.ZERO}
    signals = (0.50 + feat["sma_ratio_20"].clip(-0.2, 0.2)).clip(0, 1)
    result = Backtester(BacktestConfig()).run(feat["Close"].reset_index(drop=True), signals.reset_index(drop=True))
    assert result["final_capital"] > 0; assert result["max_drawdown_pct"] >= 0
    track_l = score_track_l("SELFTEST-L", business_quality=0.8, earnings_cashflow=0.7, balance_sheet=0.9, valuation=0.6, structural_theme=0.8, governance_risk=0.9)
    assert track_l.score > 0
    print("SELF_TEST_PASS"); return 0

def _rule_signal(features: pd.DataFrame) -> pd.Series:
    return (0.50 + 0.20 * features["sma_ratio_20"].fillna(0).clip(-0.2, 0.2) + 0.12 * (features["macd_hist"].rank(pct=True).fillna(0.5) - 0.5) + 0.10 * (features["volume_ratio"].fillna(1).clip(0, 2) / 2 - 0.5) + 0.08 * (features["market_regime_score"].fillna(0) / 2)).clip(0, 1)

def run_pipeline(args: argparse.Namespace) -> dict[str, Any]:
    workspace = Path(args.workspace); workspace.mkdir(parents=True, exist_ok=True); (workspace / "data").mkdir(parents=True, exist_ok=True)
    if args.hw: print_hw_summary()
    if args.lite: configure_tensorflow(vram_limit_mb=4096, mixed_precision=True, verbose=True)
    elif args.use_lstm: configure_tensorflow(vram_limit_mb=6144, mixed_precision=True, verbose=True)
    df = load_ohlcv(ticker=args.ticker, csv_path=args.csv, period=args.period, interval=args.interval, source="offline" if args.offline else "auto")
    features = build_features(df, horizon=args.horizon, include_price_columns=True)
    if len(features) < 80: raise RuntimeError(f"Insufficient feature rows after preprocessing: {len(features)}")
    feature_for_model = features.drop(columns=["Open", "High", "Low", "Close", "Volume"], errors="ignore")
    model_x = feature_for_model.drop(columns=["target_direction", "target_return"], errors="ignore")
    if args.no_model:
        signals = _rule_signal(features)
        model_signal = {"signal": "BUY" if float(signals.iloc[-1]) >= 0.55 else "SELL" if float(signals.iloc[-1]) <= 0.45 else "WATCH", "direction_prob": float(signals.iloc[-1]), "confidence": abs(float(signals.iloc[-1]) - 0.5) * 2, "xgb_backend": "disabled-rule-signal", "lstm_backend": "disabled"}
    else:
        model = EnsemblePredictor(ModelConfig(horizon=args.horizon, prefer_gpu=args.prefer_gpu, use_lstm=args.use_lstm, n_splits=args.cv_splits))
        model.fit(feature_for_model); model_signal = model.predict(model_x); signals = pd.Series(model.predict_proba_all(model_x), index=features.index)
    policy = RiskPolicy(capital=args.capital); entry = float(features["Close"].iloc[-1])
    decision = make_track_s_decision(args.ticker or "OFFLINE", features.iloc[-1].to_dict(), entry=entry, catalyst=args.catalyst, policy=policy, monthly_pnl_pct=args.monthly_pnl_pct, open_risk_pct=args.open_risk_pct, liquidity_ok=not args.liquidity_fail, spread_pct=args.spread_pct)
    backtest = Backtester(BacktestConfig(initial_capital=policy.allocation.track_s)).run(features["Close"].reset_index(drop=True), signals.reset_index(drop=True))
    bundle = write_report_bundle(workspace, ticker=args.ticker or "OFFLINE", policy=policy, model_signal=model_signal, decision=decision, backtest=backtest)
    append_journal(workspace, {"ticker": args.ticker or "OFFLINE", "track": "S", "action": model_signal.get("signal"), "gate": decision.gate.value, "score": decision.score, "entry": decision.entry, "stop": decision.stop, "target_2": decision.target_2, "quantity": decision.quantity, "reason": "; ".join(decision.reasons[:4])})
    summary = {"ticker": args.ticker or "OFFLINE", "rows": len(df), "feature_rows": len(features), "model_signal": model_signal, "decision": decision.to_dict(), "backtest": {k: v for k, v in backtest.items() if k not in {"portfolio_values", "trades"}}, "reports": {name: str(path) for name, path in bundle.__dict__.items() if path}}
    print("PIPELINE_SUMMARY")
    for k, v in summary.items(): print(f"{k}: {v}")
    return summary

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="stock_rtx4060 investment OS")
    p.add_argument("--test", action="store_true"); p.add_argument("--init", action="store_true"); p.add_argument("--benchmark", action="store_true"); p.add_argument("--workspace", default="./stock_rtx4060_workspace")
    p.add_argument("--ticker", default="AAPL"); p.add_argument("--csv", default=None); p.add_argument("--period", default="5y"); p.add_argument("--interval", default="1d"); p.add_argument("--horizon", type=int, default=5); p.add_argument("--capital", type=float, default=100_000.0)
    p.add_argument("--offline", action="store_true"); p.add_argument("--no-model", action="store_true"); p.add_argument("--prefer-gpu", action="store_true"); p.add_argument("--use-lstm", action="store_true"); p.add_argument("--lite", action="store_true"); p.add_argument("--hw", action="store_true"); p.add_argument("--cv-splits", type=int, default=3); p.add_argument("--catalyst", action="store_true")
    p.add_argument("--monthly-pnl-pct", type=float, default=0.0); p.add_argument("--open-risk-pct", type=float, default=0.0); p.add_argument("--spread-pct", type=float, default=0.0); p.add_argument("--liquidity-fail", action="store_true"); p.add_argument("--benchmark-rows", type=int, default=1200); p.add_argument("--benchmark-model", action="store_true")
    return p

def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv); workspace = Path(args.workspace)
    if args.test: return self_test()
    if args.init: print(f"sample_csv={write_sample_csv(workspace / 'data' / 'sample_ohlcv.csv')}"); return 0
    if args.benchmark:
        result = run_benchmark(rows=args.benchmark_rows, include_model=args.benchmark_model, prefer_gpu=args.prefer_gpu, use_lstm=args.use_lstm); json_path, md_path = write_benchmark_report(result, workspace / "benchmarks")
        print(f"benchmark_json={json_path}"); print(f"benchmark_report={md_path}"); return 0
    run_pipeline(args); return 0
if __name__ == "__main__": raise SystemExit(main(sys.argv[1:]))
