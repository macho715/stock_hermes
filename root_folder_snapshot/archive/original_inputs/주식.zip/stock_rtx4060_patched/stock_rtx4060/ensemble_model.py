"""Model layer: XGBoost CUDA when available, deterministic CPU fallback otherwise."""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any
import warnings
import numpy as np
import pandas as pd
from .hw_profile import ComputeMode, xgb_params
warnings.filterwarnings("ignore")

@dataclass(slots=True)
class ModelConfig:
    horizon: int = 5
    seq_len: int = 20
    xgb_weight: float = 0.70
    lstm_weight: float = 0.30
    n_splits: int = 5
    prefer_gpu: bool = True
    use_lstm: bool = False
    random_state: int = 42
    xgb_extra_params: dict[str, Any] = field(default_factory=dict)

class ArrayScaler:
    def __init__(self) -> None:
        self.mean_: np.ndarray | None = None; self.scale_: np.ndarray | None = None
    def fit(self, x: np.ndarray) -> "ArrayScaler":
        self.mean_ = np.nanmean(x, axis=0); scale = np.nanstd(x, axis=0); scale[scale == 0] = 1.0; self.scale_ = scale; return self
    def transform(self, x: np.ndarray) -> np.ndarray:
        if self.mean_ is None or self.scale_ is None: raise RuntimeError("Scaler is not fitted")
        return (x - self.mean_) / self.scale_
    def fit_transform(self, x: np.ndarray) -> np.ndarray: return self.fit(x).transform(x)

class SimpleLogisticClassifier:
    def __init__(self, lr: float = 0.05, epochs: int = 400, l2: float = 0.01, seed: int = 42) -> None:
        self.lr = lr; self.epochs = epochs; self.l2 = l2; self.seed = seed; self.coef_: np.ndarray | None = None; self.intercept_ = 0.0
    def fit(self, x: np.ndarray, y: np.ndarray) -> "SimpleLogisticClassifier":
        rng = np.random.default_rng(self.seed); x = np.asarray(x, dtype="float64"); y = np.asarray(y, dtype="float64")
        weights = rng.normal(0, 0.01, size=x.shape[1]); bias = 0.0
        for _ in range(self.epochs):
            logits = np.clip(x @ weights + bias, -35, 35); probs = 1 / (1 + np.exp(-logits)); error = probs - y
            weights -= self.lr * ((x.T @ error) / len(y) + self.l2 * weights); bias -= self.lr * float(np.mean(error))
        self.coef_ = weights; self.intercept_ = bias; return self
    def predict_proba(self, x: np.ndarray) -> np.ndarray:
        if self.coef_ is None: raise RuntimeError("Model is not fitted")
        logits = np.clip(np.asarray(x, dtype="float64") @ self.coef_ + self.intercept_, -35, 35); p1 = 1 / (1 + np.exp(-logits))
        return np.column_stack([1 - p1, p1])

class XGBPredictor:
    def __init__(self, config: ModelConfig):
        self.config = config; self.scaler = ArrayScaler(); self.feature_cols: list[str] = []; self.model: Any | None = None; self.backend = "uninitialized"
    def _make_xgb(self, device_mode: ComputeMode) -> Any:
        from xgboost import XGBClassifier  # type: ignore
        params = xgb_params(ComputeMode.CUDA if device_mode == ComputeMode.CUDA else ComputeMode.CPU, n_estimators=300, max_depth=5, learning_rate=0.05, random_state=self.config.random_state)
        params.update(self.config.xgb_extra_params)
        return XGBClassifier(**params)
    def fit(self, x: pd.DataFrame, y: pd.Series) -> "XGBPredictor":
        self.feature_cols = list(x.columns); x_arr = self.scaler.fit_transform(x.to_numpy(dtype="float64")); y_arr = y.to_numpy(dtype="int64")
        if self.config.prefer_gpu:
            try:
                self.model = self._make_xgb(ComputeMode.CUDA); self.model.fit(x_arr, y_arr); self.backend = "xgboost-cuda"; return self
            except Exception as exc:
                self.backend = f"xgboost-cuda-failed:{exc.__class__.__name__}"
        try:
            self.model = self._make_xgb(ComputeMode.CPU); self.model.fit(x_arr, y_arr); self.backend = "xgboost-cpu"; return self
        except Exception as exc:
            self.model = SimpleLogisticClassifier(seed=self.config.random_state).fit(x_arr, y_arr); self.backend = f"numpy-logistic-fallback:{exc.__class__.__name__}"; return self
    def predict_proba(self, x: pd.DataFrame) -> np.ndarray:
        if self.model is None: raise RuntimeError("fit() first")
        x_arr = self.scaler.transform(x[self.feature_cols].to_numpy(dtype="float64")); return np.asarray(self.model.predict_proba(x_arr))[:, 1]
    def feature_importance(self) -> pd.Series:
        if self.model is None: return pd.Series(dtype="float64")
        values = getattr(self.model, "feature_importances_", None)
        if values is None: values = np.abs(getattr(self.model, "coef_", np.zeros(len(self.feature_cols))))
        return pd.Series(values, index=self.feature_cols).sort_values(ascending=False)

class LSTMPredictor:
    def __init__(self, config: ModelConfig):
        self.config = config; self.scaler = ArrayScaler(); self.model: Any | None = None; self.backend = "disabled"
    def _sequences(self, x: np.ndarray) -> np.ndarray:
        if len(x) <= self.config.seq_len: return np.empty((0, self.config.seq_len, x.shape[1]))
        return np.stack([x[i - self.config.seq_len : i] for i in range(self.config.seq_len, len(x))])
    def fit(self, x: pd.DataFrame, y: pd.Series) -> "LSTMPredictor":
        if not self.config.use_lstm: self.backend = "disabled"; return self
        try:
            from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau  # type: ignore
            from tensorflow.keras.layers import LSTM, BatchNormalization, Dense, Dropout, Input  # type: ignore
            from tensorflow.keras.models import Sequential  # type: ignore
            from tensorflow.keras.optimizers import Adam  # type: ignore
        except Exception as exc:
            self.backend = f"tensorflow-unavailable:{exc.__class__.__name__}"; return self
        x_scaled = self.scaler.fit_transform(x.to_numpy(dtype="float64")); x_seq = self._sequences(x_scaled); y_seq = y.to_numpy(dtype="int64")[self.config.seq_len :]
        if len(x_seq) < 40: self.backend = "insufficient-sequences"; return self
        self.model = Sequential([Input(shape=(self.config.seq_len, x.shape[1])), LSTM(64, return_sequences=True), BatchNormalization(), Dropout(0.25), LSTM(32), Dropout(0.20), Dense(16, activation="relu"), Dense(1, activation="sigmoid", dtype="float32")])
        self.model.compile(optimizer=Adam(learning_rate=0.001), loss="binary_crossentropy", metrics=["accuracy"])
        self.model.fit(x_seq, y_seq, epochs=40, batch_size=32, validation_split=0.1, callbacks=[EarlyStopping(patience=6, restore_best_weights=True), ReduceLROnPlateau(patience=3, factor=0.5)], verbose=0)
        self.backend = "tensorflow-lstm"; return self
    def predict_proba(self, x: pd.DataFrame) -> np.ndarray:
        if self.model is None: return np.array([], dtype="float64")
        x_scaled = self.scaler.transform(x.to_numpy(dtype="float64")); x_seq = self._sequences(x_scaled)
        return np.array([], dtype="float64") if len(x_seq) == 0 else self.model.predict(x_seq, verbose=0).reshape(-1)

def time_series_splits(n: int, n_splits: int) -> list[tuple[np.ndarray, np.ndarray]]:
    test_size = n // (n_splits + 1)
    if n_splits < 2 or test_size < 5: return []
    out = []
    for fold in range(1, n_splits + 1):
        train_end = test_size * fold; test_end = min(train_end + test_size, n)
        if test_end > train_end: out.append((np.arange(0, train_end), np.arange(train_end, test_end)))
    return out

def accuracy_score_np(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    return float(np.mean(np.asarray(y_true) == np.asarray(y_pred))) if len(y_true) else 0.0

def roc_auc_score_np(y_true: np.ndarray, scores: np.ndarray) -> float:
    y_true = np.asarray(y_true, dtype="int64"); scores = np.asarray(scores, dtype="float64"); pos = scores[y_true == 1]; neg = scores[y_true == 0]
    if len(pos) == 0 or len(neg) == 0: return 0.5
    combined = np.concatenate([pos, neg]); order = np.argsort(combined); ranks = np.empty_like(order, dtype="float64"); ranks[order] = np.arange(1, len(combined) + 1)
    return float((ranks[: len(pos)].sum() - len(pos) * (len(pos) + 1) / 2) / (len(pos) * len(neg)))

class EnsemblePredictor:
    def __init__(self, config: ModelConfig | None = None):
        self.config = config or ModelConfig(); self.xgb = XGBPredictor(self.config); self.lstm = LSTMPredictor(self.config); self._trained = False; self.cv_results_: list[dict[str, Any]] = []
    @staticmethod
    def _split_xy(feature_df: pd.DataFrame) -> tuple[pd.DataFrame, pd.Series]:
        feat_cols = [c for c in feature_df.columns if c not in {"target_direction", "target_return"}]
        return feature_df[feat_cols], feature_df["target_direction"].astype(int)
    def fit(self, feature_df: pd.DataFrame) -> list[dict[str, Any]]:
        x, y = self._split_xy(feature_df); cv_results: list[dict[str, Any]] = []
        for fold, (train_idx, test_idx) in enumerate(time_series_splits(len(x), self.config.n_splits), start=1):
            xgb_temp = XGBPredictor(self.config).fit(x.iloc[train_idx], y.iloc[train_idx]); prob = xgb_temp.predict_proba(x.iloc[test_idx]); pred = (prob >= 0.5).astype(int)
            cv_results.append({"fold": fold, "accuracy": round(accuracy_score_np(y.iloc[test_idx].to_numpy(), pred), 4), "auc": round(roc_auc_score_np(y.iloc[test_idx].to_numpy(), prob), 4), "n_train": int(len(train_idx)), "n_test": int(len(test_idx)), "backend": xgb_temp.backend})
        self.xgb.fit(x, y); self.lstm.fit(x, y); self._trained = True; self.cv_results_ = cv_results; return cv_results
    def predict_proba_all(self, x: pd.DataFrame) -> np.ndarray:
        if not self._trained: raise RuntimeError("fit() first")
        xgb_prob = self.xgb.predict_proba(x)
        if self.config.use_lstm and self.lstm.model is not None:
            lstm_prob = self.lstm.predict_proba(x)
            if len(lstm_prob):
                pad = len(xgb_prob) - len(lstm_prob)
                if pad > 0: lstm_prob = np.concatenate([xgb_prob[:pad], lstm_prob])
                return self.config.xgb_weight * xgb_prob + self.config.lstm_weight * lstm_prob
        return xgb_prob
    def predict(self, x: pd.DataFrame) -> dict[str, Any]:
        prob = float(self.predict_proba_all(x)[-1]); signal = "BUY" if prob >= 0.55 else "SELL" if prob <= 0.45 else "WATCH"
        return {"direction_prob": prob, "signal": signal, "confidence": abs(prob - 0.5) * 2, "xgb_backend": self.xgb.backend, "lstm_backend": self.lstm.backend}
