"""Track-S / Track-L scoring and risk gates."""
from __future__ import annotations
from dataclasses import asdict, dataclass
from enum import StrEnum
from typing import Any

class Gate(StrEnum):
    GREEN = "GREEN"
    AMBER = "AMBER"
    RED = "RED"
    ZERO = "ZERO"

@dataclass(frozen=True)
class AllocationPlan:
    capital: float
    track_s: float
    track_l: float
    cash: float

@dataclass(frozen=True)
class TrackSDecision:
    ticker: str
    score: float
    gate: Gate
    risk_reward: float
    position_value: float
    quantity: int
    entry: float
    stop: float
    target_1: float
    target_2: float
    reasons: list[str]
    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["gate"] = self.gate.value
        return data

@dataclass(frozen=True)
class TrackLScore:
    ticker: str
    score: float
    gate: Gate
    reasons: list[str]

@dataclass(slots=True)
class RiskPolicy:
    capital: float = 100_000.0
    track_s_pct: float = 0.20
    track_l_pct: float = 0.75
    cash_pct: float = 0.05
    track_s_entry_score: float = 75.0
    track_l_entry_score: float = 80.0
    track_s_amber_score: float = 65.0
    risk_reward_min: float = 2.0
    initial_stop_pct: float = 0.04
    hard_stop_pct: float = 0.05
    take_profit_1_pct: float = 0.05
    take_profit_2_pct: float = 0.10
    track_s_risk_per_trade_pct: float = 0.005
    track_s_open_risk_limit_pct: float = 0.02
    track_s_monthly_stop_pct: float = -0.05
    max_track_l_single_name_pct: float = 0.12
    @property
    def allocation(self) -> AllocationPlan:
        return AllocationPlan(self.capital, self.capital * self.track_s_pct, self.capital * self.track_l_pct, self.capital * self.cash_pct)

def clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))

def score_track_s(row: dict[str, Any] | Any, *, catalyst: bool = False, risk_reward: float = 2.5) -> tuple[float, list[str]]:
    get = row.get if isinstance(row, dict) else lambda key, default=None: getattr(row, key, default)
    reasons: list[str] = []
    score = 0.0
    regime = float(get("market_regime_score", 0.0) or 0.0)
    if regime > 0:
        score += 20; reasons.append("Market regime positive")
    elif regime == 0:
        score += 10; reasons.append("Market regime neutral")
    else:
        reasons.append("Market regime negative")
    rel = float(get("return_20d", 0.0) or 0.0)
    if rel >= 0.08:
        score += 20; reasons.append("20D relative strength strong")
    elif rel > 0.02:
        score += 14; reasons.append("20D relative strength positive")
    elif rel > 0:
        score += 8; reasons.append("20D relative strength weak-positive")
    volume_ratio = float(get("volume_ratio", 0.0) or 0.0)
    if volume_ratio >= 1.5:
        score += 15; reasons.append("Volume expansion >=1.5x")
    elif volume_ratio >= 1.1:
        score += 8; reasons.append("Volume expansion moderate")
    breakout = float(get("is_20d_breakout", 0.0) or 0.0) >= 1.0
    reclaim = float(get("reclaim_5d", 0.0) or 0.0) >= 1.0
    if breakout or reclaim:
        score += 15; reasons.append("Breakout/pullback trigger present")
    if catalyst:
        score += 15; reasons.append("Catalyst confirmed")
    else:
        score += 5; reasons.append("No explicit catalyst; baseline only")
    if risk_reward >= 2.0:
        score += 15; reasons.append("Risk/reward >=2.0")
    elif risk_reward >= 1.5:
        score += 8; reasons.append("Risk/reward marginal")
    else:
        reasons.append("Risk/reward below gate")
    return round(clamp(score, 0.0, 100.0), 2), reasons

def track_s_gate(score: float, *, risk_reward: float, has_stop: bool, liquidity_ok: bool = True, spread_pct: float = 0.0, open_risk_pct: float = 0.0, monthly_pnl_pct: float = 0.0, policy: RiskPolicy | None = None) -> Gate:
    policy = policy or RiskPolicy()
    if not has_stop or monthly_pnl_pct <= policy.track_s_monthly_stop_pct or open_risk_pct > policy.track_s_open_risk_limit_pct:
        return Gate.ZERO
    if not liquidity_ok or spread_pct > 0.01 or risk_reward < 1.5:
        return Gate.RED
    if score >= policy.track_s_entry_score and risk_reward >= policy.risk_reward_min:
        return Gate.GREEN
    if score >= policy.track_s_amber_score:
        return Gate.AMBER
    return Gate.RED

def position_size_track_s(*, track_capital: float, entry: float, stop: float, risk_per_trade_pct: float = 0.005, max_position_pct: float = 0.25) -> tuple[int, float]:
    if entry <= 0 or stop <= 0 or stop >= entry:
        return 0, 0.0
    risk_amount = track_capital * risk_per_trade_pct
    per_share_risk = entry - stop
    qty_by_risk = int(risk_amount / per_share_risk)
    qty_by_cap = int((track_capital * max_position_pct) / entry)
    qty = max(0, min(qty_by_risk, qty_by_cap))
    return qty, round(qty * entry, 2)

def make_track_s_decision(ticker: str, row: dict[str, Any] | Any, *, entry: float, catalyst: bool = False, policy: RiskPolicy | None = None, monthly_pnl_pct: float = 0.0, open_risk_pct: float = 0.0, liquidity_ok: bool = True, spread_pct: float = 0.0) -> TrackSDecision:
    policy = policy or RiskPolicy()
    stop = entry * (1 - policy.initial_stop_pct)
    target_1 = entry * (1 + policy.take_profit_1_pct)
    target_2 = entry * (1 + policy.take_profit_2_pct)
    rr = (target_2 - entry) / max(entry - stop, 1e-12)
    score, reasons = score_track_s(row, catalyst=catalyst, risk_reward=rr)
    gate = track_s_gate(score, risk_reward=rr, has_stop=True, liquidity_ok=liquidity_ok, spread_pct=spread_pct, open_risk_pct=open_risk_pct, monthly_pnl_pct=monthly_pnl_pct, policy=policy)
    qty, position_value = position_size_track_s(track_capital=policy.allocation.track_s, entry=entry, stop=stop, risk_per_trade_pct=policy.track_s_risk_per_trade_pct)
    return TrackSDecision(ticker, score, gate, round(rr, 2), position_value, qty, round(entry, 4), round(stop, 4), round(target_1, 4), round(target_2, 4), reasons)

def score_track_l(ticker: str, *, business_quality: float = 0.0, earnings_cashflow: float = 0.0, balance_sheet: float = 0.0, valuation: float = 0.0, structural_theme: float = 0.0, governance_risk: float = 0.0) -> TrackLScore:
    factors = {
        "business_quality": 25 * clamp(business_quality, 0, 1),
        "earnings_cashflow": 20 * clamp(earnings_cashflow, 0, 1),
        "balance_sheet": 15 * clamp(balance_sheet, 0, 1),
        "valuation": 15 * clamp(valuation, 0, 1),
        "structural_theme": 15 * clamp(structural_theme, 0, 1),
        "governance_risk": 10 * clamp(governance_risk, 0, 1),
    }
    score = round(sum(factors.values()), 2)
    gate = Gate.GREEN if score >= 80 else Gate.AMBER if score >= 70 else Gate.RED
    return TrackLScore(ticker, score, gate, [f"{k}={v:.1f}" for k, v in factors.items()])

def rebalance_required(current_pct: float, target_pct: float, tolerance_pct: float = 0.05) -> bool:
    return abs(current_pct - target_pct) >= tolerance_pct
