"""Walk-forward backtesting with Track-S risk controls."""
from __future__ import annotations
from dataclasses import dataclass
import math
from typing import Any
import numpy as np
import pandas as pd

@dataclass(slots=True)
class BacktestConfig:
    initial_capital: float = 100_000.0
    transaction_cost: float = 0.001
    slippage: float = 0.0005
    threshold_buy: float = 0.55
    threshold_sell: float = 0.45
    stop_loss_pct: float = 0.04
    hard_stop_pct: float = 0.05
    take_profit_1_pct: float = 0.05
    take_profit_2_pct: float = 0.10
    time_stop_days: int = 20
    risk_per_trade_pct: float = 0.005
    max_position_pct: float = 0.25

class KellyCriterion:
    def __init__(self, fraction: float = 0.25) -> None:
        self.fraction = fraction
        self._wins: list[float] = []
        self._losses: list[float] = []
    def update(self, pnl: float) -> None:
        if pnl > 0: self._wins.append(float(pnl))
        elif pnl < 0: self._losses.append(abs(float(pnl)))
    def kelly_pct(self) -> float:
        if len(self._wins) < 5 or len(self._losses) < 5: return 0.10
        win_rate = len(self._wins) / (len(self._wins) + len(self._losses))
        avg_win = float(np.mean(self._wins)); avg_loss = float(np.mean(self._losses))
        if avg_loss <= 0: return 0.10
        odds = avg_win / avg_loss
        raw = win_rate - (1 - win_rate) / max(odds, 1e-12)
        return max(0.01, min(self.fraction * raw, 0.25))

class Backtester:
    def __init__(self, config: BacktestConfig | None = None) -> None:
        self.config = config or BacktestConfig()
        self.kelly = KellyCriterion()
    def _position_size(self, capital: float, price: float, stop_price: float) -> int:
        risk_amount = capital * self.config.risk_per_trade_pct
        per_share_risk = max(price - stop_price, 1e-12)
        qty_risk = int(risk_amount / per_share_risk)
        qty_cap = int((capital * self.config.max_position_pct) / max(price, 1e-12))
        qty_kelly = int((capital * self.kelly.kelly_pct()) / max(price, 1e-12))
        return max(0, min(qty_risk, qty_cap, qty_kelly))
    def run(self, prices: pd.Series, signals: pd.Series) -> dict[str, Any]:
        prices = pd.Series(prices, dtype="float64").reset_index(drop=True).dropna()
        signals = pd.Series(signals, dtype="float64").reset_index(drop=True).reindex(range(len(prices))).ffill().fillna(0.5)
        if len(prices) < 2: raise ValueError("Backtest requires at least 2 price rows")
        cash = float(self.config.initial_capital); qty = 0; entry_price = 0.0; entry_idx = -1; half_taken = False
        trades: list[dict[str, Any]] = []; portfolio_values: list[float] = []
        def exit_position(idx: int, price: float, reason: str, portion: float = 1.0) -> None:
            nonlocal cash, qty, entry_price, entry_idx, half_taken
            sell_qty = int(math.ceil(qty * portion)) if portion < 1 else qty
            sell_qty = min(qty, max(0, sell_qty))
            if sell_qty <= 0: return
            gross = sell_qty * price; cost = gross * (self.config.transaction_cost + self.config.slippage)
            cash += gross - cost; pnl = (price - entry_price) * sell_qty - cost
            self.kelly.update(pnl)
            trades.append({"idx": idx, "type": "SELL", "reason": reason, "price": round(price, 6), "quantity": sell_qty, "pnl": round(pnl, 4), "pnl_pct": round((price - entry_price) / entry_price, 6) if entry_price else 0})
            qty -= sell_qty
            if qty == 0: entry_price = 0.0; entry_idx = -1; half_taken = False
        for idx, (price, signal) in enumerate(zip(prices, signals, strict=False)):
            price = float(price); signal = float(signal)
            if qty > 0:
                pnl_pct = (price - entry_price) / entry_price; held_days = idx - entry_idx
                if pnl_pct <= -self.config.hard_stop_pct: exit_position(idx, price, "hard_stop")
                elif pnl_pct <= -self.config.stop_loss_pct: exit_position(idx, price, "stop_loss")
                elif not half_taken and pnl_pct >= self.config.take_profit_1_pct: exit_position(idx, price, "take_profit_1", 0.5); half_taken = True
                elif pnl_pct >= self.config.take_profit_2_pct: exit_position(idx, price, "take_profit_2")
                elif held_days >= self.config.time_stop_days and pnl_pct < 0.03: exit_position(idx, price, "time_stop")
                elif signal < self.config.threshold_sell: exit_position(idx, price, "signal_reversal")
            if qty == 0 and signal >= self.config.threshold_buy:
                stop = price * (1 - self.config.stop_loss_pct)
                buy_qty = self._position_size(cash, price, stop)
                invest = buy_qty * price; cost = invest * (self.config.transaction_cost + self.config.slippage)
                if buy_qty > 0 and invest + cost <= cash:
                    cash -= invest + cost; qty = buy_qty; entry_price = price; entry_idx = idx
                    trades.append({"idx": idx, "type": "BUY", "reason": "signal_threshold", "price": round(price, 6), "quantity": buy_qty, "cash_after": round(cash, 2)})
            portfolio_values.append(cash + qty * price)
        if qty > 0:
            exit_position(len(prices) - 1, float(prices.iloc[-1]), "final_liquidation")
            portfolio_values[-1] = cash
        pv = pd.Series(portfolio_values, dtype="float64")
        daily_ret = pv.pct_change().dropna(); total_ret = (pv.iloc[-1] - pv.iloc[0]) / pv.iloc[0]
        sharpe = float((daily_ret.mean() / daily_ret.std(ddof=0)) * np.sqrt(252)) if len(daily_ret) > 1 and daily_ret.std(ddof=0) > 0 else 0.0
        mdd = self._max_drawdown(pv); sell_trades = [t for t in trades if t["type"] == "SELL"]; win_trades = [t for t in sell_trades if t.get("pnl", 0) > 0]
        win_rate = len(win_trades) / len(sell_trades) if sell_trades else 0.0
        return {"total_return_pct": round(float(total_ret) * 100, 2), "sharpe_ratio": round(sharpe, 3), "max_drawdown_pct": round(float(mdd) * 100, 2), "win_rate": round(win_rate * 100, 2), "n_trades": len(sell_trades), "final_capital": round(float(pv.iloc[-1]), 2), "portfolio_values": [round(float(v), 4) for v in pv.tolist()], "trades": trades}
    @staticmethod
    def _max_drawdown(pv: pd.Series) -> float:
        peak = pv.cummax(); dd = (pv - peak) / peak.replace(0, np.nan)
        return abs(float(dd.min())) if len(dd) else 0.0
