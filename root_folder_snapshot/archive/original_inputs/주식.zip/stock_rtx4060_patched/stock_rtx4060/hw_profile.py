"""Hardware profile and GPU policy for i5-13500HX + RTX 4060 Laptop.

2026 patch notes:
- TensorFlow native-Windows CUDA is treated as unsupported after TF 2.10.
- TensorFlow GPU path is WSL2/Linux first; native Windows falls back to CPU.
- XGBoost GPU uses device='cuda' and tree_method='hist' with CPU fallback.
"""
from __future__ import annotations
from dataclasses import asdict, dataclass
from enum import StrEnum
import json, os, platform, re, subprocess, sys
from typing import Any

CPU_LOGICAL_CORES = 20
CPU_PHYSICAL_P_CORES = 6
CPU_EFFECTIVE_WORKERS = 16
CPU_INTRAOP_THREADS = 6
CPU_INTEROP_THREADS = 4
for k, v in {
    "OMP_NUM_THREADS": CPU_INTRAOP_THREADS,
    "MKL_NUM_THREADS": CPU_INTRAOP_THREADS,
    "OPENBLAS_NUM_THREADS": CPU_INTRAOP_THREADS,
    "NUMEXPR_NUM_THREADS": CPU_EFFECTIVE_WORKERS,
}.items():
    os.environ.setdefault(k, str(v))
os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "3")
os.environ.setdefault("CUDA_DEVICE_ORDER", "PCI_BUS_ID")

class ComputeMode(StrEnum):
    AUTO = "auto"
    CPU = "cpu"
    CUDA = "cuda"

@dataclass(frozen=True)
class NvidiaSmiSnapshot:
    available: bool
    name: str = "N/A"
    driver_version: str = "N/A"
    cuda_runtime: str = "N/A"
    memory_total_mib: int | None = None
    raw: str = ""

@dataclass(frozen=True)
class HardwareProfile:
    cpu_model: str
    os_name: str
    python_version: str
    is_windows: bool
    is_wsl: bool
    workers: int
    nvidia_smi: NvidiaSmiSnapshot
    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

def _run(cmd: list[str], timeout: float = 4.0) -> str:
    try:
        completed = subprocess.run(cmd, check=False, capture_output=True, text=True, timeout=timeout)
        return (completed.stdout or completed.stderr or "").strip()
    except Exception:
        return ""

def is_wsl() -> bool:
    release = platform.release().lower()
    version = platform.version().lower()
    return "microsoft" in release or "microsoft" in version or bool(os.environ.get("WSL_DISTRO_NAME"))

def probe_nvidia_smi() -> NvidiaSmiSnapshot:
    query = _run(["nvidia-smi", "--query-gpu=name,driver_version,memory.total", "--format=csv,noheader,nounits"])
    if not query:
        return NvidiaSmiSnapshot(False)
    first = query.splitlines()[0]
    parts = [p.strip() for p in first.split(",")]
    raw = _run(["nvidia-smi"], timeout=4.0)
    match = re.search(r"CUDA Version:\s*([0-9.]+)", raw)
    return NvidiaSmiSnapshot(
        True,
        parts[0] if parts else "NVIDIA GPU",
        parts[1] if len(parts) > 1 else "N/A",
        match.group(1) if match else "N/A",
        int(parts[2]) if len(parts) > 2 and parts[2].isdigit() else None,
        raw[:4000],
    )

def get_hardware_profile() -> HardwareProfile:
    return HardwareProfile(
        cpu_model="Intel Core i5-13500HX target / detected CPU via OS",
        os_name=f"{platform.system()} {platform.release()}",
        python_version=sys.version.split()[0],
        is_windows=platform.system().lower() == "windows",
        is_wsl=is_wsl(),
        workers=CPU_EFFECTIVE_WORKERS,
        nvidia_smi=probe_nvidia_smi(),
    )

def tensorflow_supported_gpu_path(profile: HardwareProfile | None = None) -> bool:
    profile = profile or get_hardware_profile()
    if profile.is_windows and not profile.is_wsl:
        return False
    return profile.nvidia_smi.available

def configure_tensorflow(vram_limit_mb: int = 6144, mixed_precision: bool = True, verbose: bool = True) -> dict[str, Any]:
    profile = get_hardware_profile()
    result = {"tensorflow_imported": False, "gpu_available": False, "device": "cpu", "reason": "not checked", "vram_limit_mb": vram_limit_mb, "mixed_precision": False}
    if profile.is_windows and not profile.is_wsl:
        result["reason"] = "TensorFlow CUDA is not supported on native Windows after TF 2.10; use WSL2/Linux or CPU."
        if verbose: print(f"[TF] CPU mode: {result['reason']}")
        return result
    try:
        import tensorflow as tf  # type: ignore
        result["tensorflow_imported"] = True
        gpus = tf.config.list_physical_devices("GPU")
        if not gpus:
            result["reason"] = "TensorFlow imported but no GPU device was reported."
            if verbose: print(f"[TF] CPU mode: {result['reason']}")
            return result
        gpu = gpus[0]
        try:
            tf.config.set_logical_device_configuration(gpu, [tf.config.LogicalDeviceConfiguration(memory_limit=vram_limit_mb)])
        except RuntimeError:
            pass
        if mixed_precision:
            try:
                from tensorflow.keras import mixed_precision as mp  # type: ignore
                mp.set_global_policy("mixed_float16")
                result["mixed_precision"] = True
            except Exception:
                pass
        try:
            tf.config.threading.set_intra_op_parallelism_threads(CPU_INTRAOP_THREADS)
            tf.config.threading.set_inter_op_parallelism_threads(CPU_INTEROP_THREADS)
        except Exception:
            pass
        result.update({"gpu_available": True, "device": "cuda:0", "reason": "ok"})
        if verbose: print(f"[TF] GPU configured: {gpu.name}, VRAM limit={vram_limit_mb} MB")
        return result
    except Exception as exc:
        result["reason"] = f"TensorFlow unavailable or failed to initialize: {exc}"
        if verbose: print(f"[TF] CPU mode: {result['reason']}")
        return result

def xgb_params(mode: ComputeMode | str = ComputeMode.AUTO, *, n_estimators: int = 400, max_depth: int = 5, learning_rate: float = 0.05, random_state: int = 42) -> dict[str, Any]:
    if not isinstance(mode, ComputeMode): mode = ComputeMode(mode)
    profile = get_hardware_profile()
    use_cuda = mode == ComputeMode.CUDA or (mode == ComputeMode.AUTO and profile.nvidia_smi.available)
    return {"n_estimators": n_estimators, "max_depth": max_depth, "learning_rate": learning_rate, "subsample": 0.8, "colsample_bytree": 0.8, "eval_metric": "logloss", "random_state": random_state, "tree_method": "hist", "n_jobs": CPU_EFFECTIVE_WORKERS, "device": "cuda" if use_cuda else "cpu"}

def print_hw_summary() -> None:
    profile = get_hardware_profile()
    print("=" * 70)
    print("stock_rtx4060 hardware policy")
    print(json.dumps(profile.to_dict(), indent=2, ensure_ascii=False))
    print("TF GPU path:", "WSL2/Linux" if tensorflow_supported_gpu_path(profile) else "CPU/native-Windows fallback")
    print("XGBoost params:", xgb_params())
    print("=" * 70)

if __name__ == "__main__":
    print_hw_summary()
