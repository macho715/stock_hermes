"""Data loading helpers for CSV/yfinance and deterministic offline demos."""
from __future__ import annotations
from pathlib import Path
from typing import Literal
import numpy as np
import pandas as pd
from .feature_engine import normalize_ohlcv


def make_dummy_ohlcv(n: int = 500, seed: int = 42, start: str = "2022-01-03") -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    returns = rng.normal(0.00035, 0.014, n) + 0.002 * np.sin(np.linspace(0, 10 * np.pi, n))
    close = 100 * np.cumprod(1 + returns)
    high = close * (1 + rng.uniform(0.001, 0.018, n)); low = close * (1 - rng.uniform(0.001, 0.018, n))
    open_ = low + rng.uniform(0, 1, n) * (high - low); volume = rng.integers(1_000_000, 6_000_000, n).astype(float)
    return pd.DataFrame({"Open": open_, "High": high, "Low": low, "Close": close, "Volume": volume}, index=pd.bdate_range(start=start, periods=n))


def read_csv_ohlcv(path: str | Path) -> pd.DataFrame:
    path = Path(path)
    if not path.exists(): raise FileNotFoundError(path)
    try: df = pd.read_csv(path, engine="pyarrow", dtype_backend="pyarrow")
    except Exception: df = pd.read_csv(path)
    date_cols = [c for c in df.columns if str(c).lower() in {"date", "datetime", "time", "timestamp"}]
    if date_cols:
        df[date_cols[0]] = pd.to_datetime(df[date_cols[0]], errors="coerce"); df = df.set_index(date_cols[0])
    return normalize_ohlcv(df)


def download_yfinance(ticker: str, period: str = "5y", interval: str = "1d") -> pd.DataFrame:
    try: import yfinance as yf  # type: ignore
    except Exception as exc: raise RuntimeError("yfinance 미설치: CSV를 사용하거나 `pip install yfinance` 실행") from exc
    df = yf.download(ticker, period=period, interval=interval, auto_adjust=True, progress=False)
    if df is None or df.empty: raise RuntimeError(f"No market data returned for ticker={ticker}")
    return normalize_ohlcv(df)


def load_ohlcv(*, ticker: str | None = None, csv_path: str | Path | None = None, period: str = "5y", interval: str = "1d", source: Literal["auto", "csv", "yfinance", "offline"] = "auto") -> pd.DataFrame:
    if source == "offline": return make_dummy_ohlcv()
    if csv_path is not None: return read_csv_ohlcv(csv_path)
    if ticker and source in {"auto", "yfinance"}: return download_yfinance(ticker, period=period, interval=interval)
    return make_dummy_ohlcv()


def write_sample_csv(path: str | Path, rows: int = 500) -> Path:
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    make_dummy_ohlcv(rows).reset_index(names="Date").to_csv(path, index=False)
    return path
