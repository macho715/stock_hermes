"""Compatibility entrypoint.

Examples:
    python main.py --test
    python main.py --offline --no-model
    python main.py --ticker AAPL --period 5y --prefer-gpu
"""
from stock_rtx4060.main import main

if __name__ == "__main__":
    raise SystemExit(main())
