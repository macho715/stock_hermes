from backtester import BacktestConfig, Backtester
from ensemble_model import EnsemblePredictor, ModelConfig
from feature_engine import TechnicalIndicators, feature_columns, make_synthetic_ohlcv
import pandas as pd


def test_offline_pipeline_smoke():
    df = make_synthetic_ohlcv(360)
    features = TechnicalIndicators(df).build_all(horizon=5)
    cols = feature_columns(features)
    assert len(cols) >= 25
    model = EnsemblePredictor(ModelConfig(horizon=5, backend="sklearn", n_splits=2)).fit(features[cols], features["target"].astype(int))
    probs = model.predict_proba_all(features[cols])
    result = Backtester(BacktestConfig()).run(features["close"].reset_index(drop=True), pd.Series(probs))
    assert result["final_equity"] > 0
