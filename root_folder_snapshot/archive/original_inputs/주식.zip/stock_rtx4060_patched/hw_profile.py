"""Hardware validation helpers for the stock_rtx4060 investment OS."""
from __future__ import annotations

import importlib.metadata
import importlib.util
import json
import os
import platform
import subprocess
import sys
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class ProbeResult:
    name: str
    available: bool
    detail: str
    elapsed_ms: float

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class HardwareProfile:
    timestamp_utc: str
    python: str
    os: str
    processor: str
    nvidia_smi: ProbeResult
    tensorflow: ProbeResult
    xgboost: ProbeResult
    recommended_backend: str
    lite_mode: bool
    notes: list[str]

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["nvidia_smi"] = self.nvidia_smi.to_dict()
        payload["tensorflow"] = self.tensorflow.to_dict()
        payload["xgboost"] = self.xgboost.to_dict()
        return payload


def _run_command(cmd: list[str], timeout_s: int = 6) -> ProbeResult:
    import time
    start = time.perf_counter()
    try:
        completed = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout_s, check=False)
        elapsed = (time.perf_counter() - start) * 1000.0
        output = (completed.stdout or completed.stderr or "").strip()
        if len(output) > 900:
            output = output[:900] + " ...<truncated>"
        return ProbeResult(" ".join(cmd), completed.returncode == 0, output or f"returncode={completed.returncode}", round(elapsed, 2))
    except FileNotFoundError as exc:
        elapsed = (time.perf_counter() - start) * 1000.0
        return ProbeResult(" ".join(cmd), False, f"not found: {exc}", round(elapsed, 2))
    except subprocess.TimeoutExpired:
        elapsed = (time.perf_counter() - start) * 1000.0
        return ProbeResult(" ".join(cmd), False, f"timeout after {timeout_s}s", round(elapsed, 2))


def probe_nvidia_smi(timeout_s: int = 5) -> ProbeResult:
    return _run_command([
        "nvidia-smi",
        "--query-gpu=name,driver_version,memory.total,compute_cap",
        "--format=csv,noheader",
    ], timeout_s=timeout_s)


def _metadata_probe(package: str) -> ProbeResult:
    import time
    start = time.perf_counter()
    spec = importlib.util.find_spec(package)
    elapsed = (time.perf_counter() - start) * 1000.0
    if spec is None:
        return ProbeResult(package, False, "package metadata not found", round(elapsed, 2))
    try:
        version = importlib.metadata.version(package)
    except importlib.metadata.PackageNotFoundError:
        version = "installed-path-detected"
    return ProbeResult(package, True, f"metadata-only probe: version={version}; use --deep-probe for runtime GPU check", round(elapsed, 2))


def probe_tensorflow(timeout_s: int = 8, *, deep: bool = False) -> ProbeResult:
    if not deep:
        return _metadata_probe("tensorflow")
    code = (
        "import json; import tensorflow as tf; "
        "print(json.dumps({'version': tf.__version__, 'gpus': [d.name for d in tf.config.list_physical_devices('GPU')]}))"
    )
    return _run_command([sys.executable, "-c", code], timeout_s=timeout_s)


def probe_xgboost(timeout_s: int = 8, *, deep: bool = False) -> ProbeResult:
    if not deep:
        return _metadata_probe("xgboost")
    code = "import json; import xgboost as xgb; print(json.dumps({'version': xgb.__version__}))"
    return _run_command([sys.executable, "-c", code], timeout_s=timeout_s)


def detect_hardware(*, lite: bool = False, timeout_s: int = 6, deep_probe: bool = False) -> HardwareProfile:
    nvidia = probe_nvidia_smi(timeout_s=max(3, timeout_s))
    tensorflow = probe_tensorflow(timeout_s=max(3, timeout_s), deep=deep_probe)
    xgboost = probe_xgboost(timeout_s=max(3, timeout_s), deep=deep_probe)
    notes: list[str] = []
    if not deep_probe:
        notes.append("TensorFlow/XGBoost probes are metadata-only. Run with --deep-probe for runtime import/GPU checks.")
    if platform.system().lower() == "windows" and not tensorflow.available:
        notes.append("TensorFlow GPU is not assumed on Windows Native. Use WSL2 for TF>=2.11 GPU, or keep TensorFlow disabled.")
    if not nvidia.available:
        notes.append("nvidia-smi was not available. GPU benchmark is skipped.")
    if not xgboost.available:
        notes.append("xgboost package metadata was not found. sklearn-compatible NumPy fallback is recommended.")
    if lite:
        notes.append("Lite mode enabled: prefer CPU/offline path and lower row counts.")
    recommended = "cuda" if nvidia.available and xgboost.available and deep_probe else "sklearn"
    if lite and recommended == "cuda":
        recommended = "xgboost-cpu"
    return HardwareProfile(
        timestamp_utc=datetime.now(timezone.utc).isoformat(timespec="seconds"),
        python=sys.version.replace("\n", " "),
        os=f"{platform.system()} {platform.release()} ({platform.platform()})",
        processor=platform.processor() or platform.machine(),
        nvidia_smi=nvidia,
        tensorflow=tensorflow,
        xgboost=xgboost,
        recommended_backend=recommended,
        lite_mode=lite,
        notes=notes,
    )


def write_validation_log(output_dir: Path, *, lite: bool = False, timeout_s: int = 6, deep_probe: bool = False) -> HardwareProfile:
    output_dir.mkdir(parents=True, exist_ok=True)
    profile = detect_hardware(lite=lite, timeout_s=timeout_s, deep_probe=deep_probe)
    (output_dir / "environment_validation.json").write_text(json.dumps(profile.to_dict(), indent=2, ensure_ascii=False), encoding="utf-8")
    lines = [
        "# Environment Validation Log", "", f"- Timestamp UTC: {profile.timestamp_utc}", f"- Python: {profile.python}", f"- OS: {profile.os}", f"- Processor: {profile.processor}", f"- Recommended backend: `{profile.recommended_backend}`", f"- Lite mode: `{profile.lite_mode}`", f"- Deep probe: `{deep_probe}`", "", "| Probe | Available | Detail | Elapsed ms |", "|---|---:|---|---:|",
    ]
    for probe in [profile.nvidia_smi, profile.tensorflow, profile.xgboost]:
        detail = probe.detail.replace("\n", " ").replace("|", "/")
        lines.append(f"| {probe.name} | {probe.available} | {detail} | {probe.elapsed_ms:.2f} |")
    if profile.notes:
        lines.extend(["", "## Notes"])
        lines.extend(f"- {note}" for note in profile.notes)
    (output_dir / "environment_validation.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return profile


def print_hw_summary(profile: HardwareProfile) -> None:
    print("Environment validation")
    print(f"  recommended_backend={profile.recommended_backend}")
    print(f"  nvidia_smi={profile.nvidia_smi.available}: {profile.nvidia_smi.detail[:140]}")
    print(f"  tensorflow={profile.tensorflow.available}: {profile.tensorflow.detail[:140]}")
    print(f"  xgboost={profile.xgboost.available}: {profile.xgboost.detail[:140]}")


if __name__ == "__main__":
    out = Path(os.environ.get("STOCK_RTX4060_REPORTS", "reports"))
    print_hw_summary(write_validation_log(out, deep_probe="--deep" in sys.argv))
