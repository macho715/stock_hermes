"""Model layer for rule-assisted stock candidate scoring.

The sandbox-compatible default backend is a small NumPy logistic model. The CLI
keeps the backend name `sklearn` for compatibility with the uploaded plan's CPU
path, but the code does not import scikit-learn at module import time. XGBoost
CPU/CUDA is available as an explicit optional backend.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import numpy as np
import pandas as pd


@dataclass
class ModelConfig:
    horizon: int = 5
    backend: str = "sklearn"  # sklearn-compatible NumPy fallback | xgboost-cpu | cuda
    enable_lstm: bool = False
    n_splits: int = 5
    random_state: int = 42
    test_size: int | None = None
    gap: int | None = None
    xgb_params: dict[str, Any] = field(
        default_factory=lambda: {
            "n_estimators": 220,
            "max_depth": 4,
            "learning_rate": 0.05,
            "subsample": 0.85,
            "colsample_bytree": 0.85,
            "eval_metric": "logloss",
            "random_state": 42,
            "tree_method": "hist",
            "n_jobs": 0,
        }
    )


@dataclass
class FoldMetric:
    fold: int
    train_rows: int
    test_rows: int
    accuracy: float
    balanced_accuracy: float
    auc: float | None

    def to_dict(self) -> dict[str, Any]:
        return {
            "fold": self.fold,
            "train_rows": self.train_rows,
            "test_rows": self.test_rows,
            "accuracy": round(self.accuracy, 5),
            "balanced_accuracy": round(self.balanced_accuracy, 5),
            "auc": None if self.auc is None else round(self.auc, 5),
        }


class SimpleScaler:
    def fit(self, X: pd.DataFrame | np.ndarray) -> "SimpleScaler":
        arr = np.asarray(X, dtype=float)
        self.mean_ = arr.mean(axis=0)
        self.std_ = arr.std(axis=0)
        self.std_[self.std_ == 0] = 1.0
        return self

    def transform(self, X: pd.DataFrame | np.ndarray) -> np.ndarray:
        return (np.asarray(X, dtype=float) - self.mean_) / self.std_


class NumpyLogisticClassifier:
    """Small deterministic logistic classifier for offline smoke tests/benchmarks."""

    def __init__(self, *, lr: float = 0.045, epochs: int = 220, l2: float = 0.03, random_state: int = 42) -> None:
        self.lr = lr
        self.epochs = epochs
        self.l2 = l2
        self.random_state = random_state

    @staticmethod
    def _sigmoid(z: np.ndarray) -> np.ndarray:
        z = np.clip(z, -40, 40)
        return 1.0 / (1.0 + np.exp(-z))

    def fit(self, X: np.ndarray, y: pd.Series | np.ndarray) -> "NumpyLogisticClassifier":
        X_arr = np.asarray(X, dtype=float)
        y_arr = np.asarray(y, dtype=float)
        rng = np.random.default_rng(self.random_state)
        self.weights_ = rng.normal(0.0, 0.01, X_arr.shape[1])
        self.bias_ = 0.0
        n = max(len(y_arr), 1)
        for _ in range(self.epochs):
            p = self._sigmoid(X_arr @ self.weights_ + self.bias_)
            error = p - y_arr
            grad_w = (X_arr.T @ error) / n + self.l2 * self.weights_
            grad_b = float(error.mean())
            self.weights_ -= self.lr * grad_w
            self.bias_ -= self.lr * grad_b
        return self

    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        X_arr = np.asarray(X, dtype=float)
        p1 = self._sigmoid(X_arr @ self.weights_ + self.bias_)
        return np.column_stack([1.0 - p1, p1])


def _accuracy(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    return float((y_true == y_pred).mean()) if len(y_true) else 0.0


def _balanced_accuracy(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    vals: list[float] = []
    for cls in (0, 1):
        mask = y_true == cls
        if mask.any():
            vals.append(float((y_pred[mask] == cls).mean()))
    return float(np.mean(vals)) if vals else 0.0


def _auc_score(y_true: np.ndarray, score: np.ndarray) -> float | None:
    y_true = np.asarray(y_true, dtype=int)
    pos = score[y_true == 1]
    neg = score[y_true == 0]
    if len(pos) == 0 or len(neg) == 0:
        return None
    # Mann-Whitney formulation of ROC AUC.
    combined = np.concatenate([pos, neg])
    order = np.argsort(combined)
    ranks = np.empty_like(order, dtype=float)
    ranks[order] = np.arange(1, len(combined) + 1)
    pos_ranks = ranks[: len(pos)]
    auc = (pos_ranks.sum() - len(pos) * (len(pos) + 1) / 2.0) / (len(pos) * len(neg))
    return float(auc)


def _time_series_splits(n_rows: int, *, n_splits: int, test_size: int | None, gap: int) -> list[tuple[np.ndarray, np.ndarray]]:
    if n_splits < 2:
        n_splits = 2
    if test_size is None:
        test_size = max(20, n_rows // (n_splits + 2))
    splits: list[tuple[np.ndarray, np.ndarray]] = []
    for split_no in range(n_splits, 0, -1):
        test_end = n_rows - (split_no - 1) * test_size
        test_start = test_end - test_size
        train_end = max(0, test_start - gap)
        if train_end <= 20 or test_start < 0 or test_end > n_rows:
            continue
        splits.append((np.arange(0, train_end), np.arange(test_start, test_end)))
    return splits


class EnsemblePredictor:
    def __init__(self, config: ModelConfig | None = None):
        self.config = config or ModelConfig()
        if self.config.backend not in {"sklearn", "xgboost-cpu", "cuda"}:
            raise ValueError("backend must be one of: sklearn, xgboost-cpu, cuda")
        self.scaler = SimpleScaler()
        self.feature_cols: list[str] = []
        self.primary: Any | None = None
        self.fold_metrics: list[FoldMetric] = []

    def _make_primary(self) -> Any:
        if self.config.backend == "sklearn":
            return NumpyLogisticClassifier(random_state=self.config.random_state)
        try:
            from xgboost import XGBClassifier
        except Exception as exc:  # pragma: no cover - optional dependency path
            raise RuntimeError("xgboost backend requested but xgboost import failed") from exc
        params = dict(self.config.xgb_params)
        params["device"] = "cuda" if self.config.backend == "cuda" else "cpu"
        return XGBClassifier(**params)

    def fit(self, X: pd.DataFrame, y: pd.Series) -> "EnsemblePredictor":
        if len(X) != len(y):
            raise ValueError("X and y length mismatch")
        if len(X) < 80:
            raise ValueError("at least 80 rows are required for walk-forward training")
        self.feature_cols = list(X.columns)
        self.fold_metrics = []
        split_count = max(2, min(self.config.n_splits, max(2, len(X) // 90)))
        test_size = self.config.test_size
        if test_size is None and len(X) >= 360:
            test_size = max(30, min(90, len(X) // (split_count + 2)))
        splits = _time_series_splits(
            len(X),
            n_splits=split_count,
            test_size=test_size,
            gap=self.config.horizon if self.config.gap is None else self.config.gap,
        )
        for fold, (train_idx, test_idx) in enumerate(splits, start=1):
            x_train = X.iloc[train_idx]
            y_train = y.iloc[train_idx]
            x_test = X.iloc[test_idx]
            y_test = y.iloc[test_idx]
            scaler = SimpleScaler().fit(x_train)
            model = self._make_primary()
            model.fit(scaler.transform(x_train), y_train)
            proba = model.predict_proba(scaler.transform(x_test))[:, 1]
            pred = (proba >= 0.5).astype(int)
            y_test_arr = y_test.to_numpy(dtype=int)
            self.fold_metrics.append(
                FoldMetric(
                    fold=fold,
                    train_rows=len(train_idx),
                    test_rows=len(test_idx),
                    accuracy=_accuracy(y_test_arr, pred),
                    balanced_accuracy=_balanced_accuracy(y_test_arr, pred),
                    auc=_auc_score(y_test_arr, proba),
                )
            )
        self.scaler = SimpleScaler().fit(X)
        self.primary = self._make_primary()
        self.primary.fit(self.scaler.transform(X), y)
        return self

    def predict_proba_all(self, X: pd.DataFrame) -> np.ndarray:
        if self.primary is None:
            raise RuntimeError("model is not fitted")
        X_local = X[self.feature_cols]
        return self.primary.predict_proba(self.scaler.transform(X_local))[:, 1]

    def predict_latest(self, X: pd.DataFrame) -> float:
        return float(self.predict_proba_all(X.tail(1))[0])


def summarize_cv(fold_metrics: list[FoldMetric]) -> dict[str, Any]:
    if not fold_metrics:
        return {"folds": 0, "accuracy_mean": None, "balanced_accuracy_mean": None, "auc_mean": None}
    aucs = [m.auc for m in fold_metrics if m.auc is not None]
    return {
        "folds": len(fold_metrics),
        "accuracy_mean": round(float(np.mean([m.accuracy for m in fold_metrics])), 5),
        "balanced_accuracy_mean": round(float(np.mean([m.balanced_accuracy for m in fold_metrics])), 5),
        "auc_mean": None if not aucs else round(float(np.mean(aucs)), 5),
        "fold_details": [m.to_dict() for m in fold_metrics],
    }
