# Environment Validation Log

- Timestamp UTC: 2026-05-02T09:40:22+00:00
- Python: 3.13.5 (main, Jun 25 2025, 18:55:22) [GCC 14.2.0]
- OS: Linux 4.4.0 (Linux-4.4.0-x86_64-with-glibc2.41)
- Processor: x86_64
- Recommended backend: `sklearn`
- Lite mode: `True`

| Probe | Available | Detail | Elapsed ms |
|---|---:|---|---:|
| nvidia-smi --query-gpu=name,driver_version,memory.total,compute_cap --format=csv,noheader | False | not found: [Errno 2] No such file or directory: 'nvidia-smi' | 11.31 |
| /opt/pyvenv/bin/python -c import json;import tensorflow as tf;print(json.dumps({'version': tf.__version__, 'gpus': [d.name for d in tf.config.list_physical_devices('GPU')]})) | False | timeout after 3s | 3089.22 |
| /opt/pyvenv/bin/python -c import json; import xgboost as xgb; print(json.dumps({'version': xgb.__version__})) | False | timeout after 3s | 3092.26 |

## Notes
- nvidia-smi was not available. GPU benchmark is skipped.
- xgboost import/probe failed or timed out. sklearn fallback is recommended.
- Lite mode enabled: prefer sklearn or CPU backend and lower row/worker counts.
