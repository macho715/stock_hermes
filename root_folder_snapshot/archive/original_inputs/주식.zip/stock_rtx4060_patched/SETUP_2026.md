# SETUP_2026 — Windows i5-13500HX + RTX 4060 Laptop

## 1. Base environment

```powershell
winget install Python.Python.3.11
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements-base.txt
python main.py --test
```

## 2. Data source

```powershell
pip install -r requirements-data.txt
python main.py --ticker AAPL --period 5y --horizon 5
```

CSV is preferred for reproducibility:

```powershell
python main.py --init --workspace .\workspace
python main.py --csv .\workspace\data\sample_ohlcv.csv --ticker LOCAL --no-model
```

## 3. XGBoost GPU path

```powershell
pip install -r requirements-ml.txt
python main.py --ticker NVDA --prefer-gpu --workspace .\workspace
```

The patched scripts use `device='cuda'` and `tree_method='hist'`, then fall back to CPU if CUDA is unavailable.

## 4. TensorFlow GPU path

Native Windows TensorFlow CUDA is not assumed. Use WSL2/Linux for modern TensorFlow GPU:

```bash
wsl --install -d Ubuntu-24.04
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements-base.txt
pip install -r requirements-gpu-wsl2.txt
python main.py --ticker AAPL --prefer-gpu --use-lstm --workspace ./workspace
```

## 5. Benchmark

```powershell
python main.py --benchmark --workspace .\workspace --benchmark-rows 1200
python main.py --benchmark --benchmark-model --prefer-gpu --workspace .\workspace --benchmark-rows 3000
```

The second command should be run on the target RTX 4060/WSL2 machine for actual GPU timing.

## 6. Report files

Generated report paths:

```text
workspace/reports/daily_brief_YYYY-MM-DD.md
workspace/reports/risk_dashboard_YYYY-MM-DD.md
workspace/reports/monthly_scorecard_YYYY-MM-DD.md
workspace/reports/track_l_thesis_YYYY-MM-DD.md
workspace/journal/journal.csv
```
