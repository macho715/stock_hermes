"""Feature engineering for OHLCV data.

The implementation uses only pandas/numpy to keep the offline path reproducible.
All predictive labels are generated from future returns after features are shifted,
so the training set never receives direct future prices as features.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

OHLCV_COLUMNS = ("Open", "High", "Low", "Close", "Volume")


def make_synthetic_ohlcv(n: int = 900, seed: int = 42) -> pd.DataFrame:
    """Create deterministic OHLCV fixture for tests, offline demos and benchmarks."""
    if n < 260:
        raise ValueError("n must be >= 260 so long-window indicators can be computed")
    rng = np.random.default_rng(seed)
    drift = rng.normal(0.00035, 0.00012, n)
    volatility = rng.uniform(0.008, 0.026, n)
    shocks = rng.normal(drift, volatility)
    seasonal = 0.003 * np.sin(np.linspace(0.0, 12.0 * np.pi, n))
    close = 100.0 * np.exp(np.cumsum(shocks + seasonal / 40.0))
    high = close * (1.0 + rng.uniform(0.002, 0.022, n))
    low = close * (1.0 - rng.uniform(0.002, 0.022, n))
    open_ = low + rng.random(n) * (high - low)
    volume_base = rng.integers(900_000, 7_000_000, n).astype(float)
    volume = volume_base * (1.0 + np.abs(shocks) * 18.0)
    index = pd.bdate_range("2021-01-04", periods=n)
    return pd.DataFrame(
        {"Open": open_, "High": high, "Low": low, "Close": close, "Volume": volume},
        index=index,
    )


def _rsi(close: pd.Series, period: int = 14) -> pd.Series:
    delta = close.diff()
    up = delta.clip(lower=0).ewm(alpha=1 / period, adjust=False).mean()
    down = (-delta.clip(upper=0)).ewm(alpha=1 / period, adjust=False).mean()
    rs = up / down.replace(0, np.nan)
    return 100.0 - (100.0 / (1.0 + rs))


def _true_range(df: pd.DataFrame) -> pd.Series:
    high, low, close = df["High"], df["Low"], df["Close"]
    return pd.concat(
        [
            high - low,
            (high - close.shift(1)).abs(),
            (low - close.shift(1)).abs(),
        ],
        axis=1,
    ).max(axis=1)


def _max_drawdown(close: pd.Series, window: int) -> pd.Series:
    peak = close.rolling(window).max()
    return close / peak - 1.0


@dataclass
class TechnicalIndicators:
    df: pd.DataFrame

    def __post_init__(self) -> None:
        missing = set(OHLCV_COLUMNS) - set(self.df.columns)
        if missing:
            raise ValueError(f"missing OHLCV columns: {sorted(missing)}")
        self.df = self.df.copy().sort_index()

    def build_all(self, *, horizon: int = 5, min_rows: int = 260) -> pd.DataFrame:
        if horizon <= 0:
            raise ValueError("horizon must be positive")
        df = self.df.copy()
        close = df["Close"]
        high = df["High"]
        low = df["Low"]
        volume = df["Volume"]

        features = pd.DataFrame(index=df.index)
        features["close"] = close
        features["ret_1"] = close.pct_change(1)
        features["ret_2"] = close.pct_change(2)
        features["ret_5"] = close.pct_change(5)
        features["ret_10"] = close.pct_change(10)
        features["ret_20"] = close.pct_change(20)
        features["ret_60"] = close.pct_change(60)
        for window in (5, 10, 20, 50, 100, 200):
            sma = close.rolling(window).mean()
            features[f"sma_{window}_ratio"] = close / sma - 1.0
            features[f"vol_{window}"] = close.pct_change().rolling(window).std()
        ema12 = close.ewm(span=12, adjust=False).mean()
        ema26 = close.ewm(span=26, adjust=False).mean()
        macd = ema12 - ema26
        features["macd"] = macd / close
        features["macd_signal"] = macd.ewm(span=9, adjust=False).mean() / close
        features["macd_hist"] = features["macd"] - features["macd_signal"]
        features["rsi_14"] = _rsi(close, 14) / 100.0
        tr = _true_range(df)
        atr14 = tr.rolling(14).mean()
        features["atr_14_pct"] = atr14 / close
        features["range_pct"] = (high - low) / close
        features["close_position"] = (close - low) / (high - low).replace(0, np.nan)
        features["volume_z20"] = (volume - volume.rolling(20).mean()) / volume.rolling(20).std()
        features["volume_ratio20"] = volume / volume.rolling(20).mean()
        features["obv"] = (np.sign(close.diff()).fillna(0.0) * volume).cumsum() / volume.expanding().mean()
        features["mdd_20"] = _max_drawdown(close, 20)
        features["mdd_60"] = _max_drawdown(close, 60)
        features["breakout_20"] = (close / close.rolling(20).max() - 1.0)
        features["pullback_20"] = (close / close.rolling(20).mean() - 1.0)
        features["market_regime"] = (close.rolling(50).mean() > close.rolling(200).mean()).astype(float)
        features["weekday"] = features.index.dayofweek.astype(float) / 4.0
        features["month"] = features.index.month.astype(float) / 12.0

        future_return = close.shift(-horizon) / close - 1.0
        features["target"] = (future_return > 0.0).astype(int)
        features["future_return"] = future_return
        # Shift every feature except labels one bar forward to prevent same-bar leakage.
        label_cols = {"target", "future_return"}
        feature_cols_local = [col for col in features.columns if col not in label_cols]
        features[feature_cols_local] = features[feature_cols_local].shift(1)
        features = features.replace([np.inf, -np.inf], np.nan).dropna()
        if len(features) < max(30, min_rows // 4):
            raise ValueError(f"too few feature rows after cleaning: {len(features)}")
        return features


def feature_columns(frame: pd.DataFrame) -> list[str]:
    excluded = {"target", "future_return", "close"}
    return [c for c in frame.columns if c not in excluded]
