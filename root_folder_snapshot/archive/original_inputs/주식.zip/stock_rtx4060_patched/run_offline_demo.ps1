python .\main.py --offline-fixture --ticker AAPL --horizon 5 --rows 900 --output-dir .\reports\offline_demo
