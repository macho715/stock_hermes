# stock_rtx4060 — Patched Investment OS

This patched bundle converts the uploaded `주식.zip` scripts into a runnable project for:

- Track-S short-term rule scoring
- Track-L long-term allocation/thesis reports
- Risk Gate / ZERO rules
- Offline and CSV-based OHLCV processing
- Optional yfinance data download
- Optional XGBoost CUDA and TensorFlow LSTM paths with CPU fallback
- Markdown reports and journal output
- Benchmark harness

> This is a decision-support and backtesting tool. It does not execute broker orders and does not provide personalized investment advice.

## Quick start

```powershell
cd stock_rtx4060_patched
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements-base.txt
python main.py --test
python main.py --init --workspace .\workspace
python main.py --offline --no-model --workspace .\workspace --ticker DEMO --catalyst
python main.py --benchmark --workspace .\workspace --benchmark-rows 1200
```

## Real ticker run

```powershell
pip install yfinance
python main.py --ticker AAPL --period 5y --horizon 5 --workspace .\workspace
```

`yfinance` is treated as research/education data access. For reproducible research, prefer CSV input:

```powershell
python main.py --csv .\workspace\data\sample_ohlcv.csv --ticker LOCAL --no-model
```

## GPU run policy

### XGBoost

```powershell
pip install xgboost>=3.2
python main.py --ticker NVDA --period 5y --prefer-gpu --workspace .\workspace
```

If CUDA fails, `ensemble_model.py` falls back to CPU XGBoost, then to a deterministic NumPy logistic fallback.

### TensorFlow LSTM

Modern TensorFlow CUDA is not assumed on native Windows. Use WSL2/Linux for GPU TensorFlow:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements-base.txt
pip install -r requirements-gpu-wsl2.txt
python main.py --ticker AAPL --prefer-gpu --use-lstm --workspace ./workspace
```

## Outputs

```text
workspace/
├── data/sample_ohlcv.csv
├── journal/journal.csv
├── reports/
│   ├── daily_brief_YYYY-MM-DD.md
│   ├── risk_dashboard_YYYY-MM-DD.md
│   ├── monthly_scorecard_YYYY-MM-DD.md
│   └── track_l_thesis_YYYY-MM-DD.md
└── benchmarks/
    ├── benchmark_result.json
    └── benchmark_report.md
```

## Validation performed in this environment

```text
python -S -m py_compile main.py stock_rtx4060/*.py  -> PASS
python -S main.py --test                            -> PASS
python -S main.py --offline --no-model              -> PASS
python -S main.py --benchmark --benchmark-rows 300  -> PASS
```

The local container has no RTX 4060 access, so the included benchmark report is a CPU/offline smoke benchmark. Run `--benchmark-model --prefer-gpu` on the target RTX 4060 WSL2 machine for actual GPU timing.
