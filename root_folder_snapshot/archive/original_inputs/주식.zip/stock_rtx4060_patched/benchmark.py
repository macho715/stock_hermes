"""Benchmark runner for feature, model and backtest stages."""
from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any

import pandas as pd

from backtester import BacktestConfig, Backtester
from ensemble_model import EnsemblePredictor, ModelConfig, summarize_cv
from feature_engine import TechnicalIndicators, feature_columns, make_synthetic_ohlcv


def run_benchmark(
    output_dir: Path,
    *,
    rows: int = 900,
    repeats: int = 3,
    backend: str = "sklearn",
    horizon: int = 5,
    capital: float = 100_000.0,
) -> dict[str, Any]:
    output_dir.mkdir(parents=True, exist_ok=True)
    records: list[dict[str, Any]] = []
    for repeat in range(1, repeats + 1):
        record: dict[str, Any] = {"repeat": repeat, "rows": rows, "backend": backend, "horizon": horizon}
        started = time.perf_counter()
        df = make_synthetic_ohlcv(rows, seed=40 + repeat)
        record["fixture_ms"] = round((time.perf_counter() - started) * 1000.0, 2)

        started = time.perf_counter()
        features = TechnicalIndicators(df).build_all(horizon=horizon)
        record["feature_rows"] = len(features)
        record["feature_cols"] = len(feature_columns(features))
        record["feature_ms"] = round((time.perf_counter() - started) * 1000.0, 2)

        X = features[feature_columns(features)]
        y = features["target"].astype(int)
        started = time.perf_counter()
        model = EnsemblePredictor(ModelConfig(horizon=horizon, backend=backend, n_splits=3)).fit(X, y)
        probs = pd.Series(model.predict_proba_all(X), index=features.index)
        record["fit_predict_ms"] = round((time.perf_counter() - started) * 1000.0, 2)
        record["cv_accuracy_mean"] = summarize_cv(model.fold_metrics)["accuracy_mean"]

        started = time.perf_counter()
        prices = features["close"].reset_index(drop=True)
        backtest = Backtester(BacktestConfig(initial_capital=capital)).run(prices, probs.reset_index(drop=True))
        record["backtest_ms"] = round((time.perf_counter() - started) * 1000.0, 2)
        record["total_return_pct"] = backtest["total_return_pct"]
        record["max_drawdown_pct"] = backtest["max_drawdown_pct"]
        record["trade_count"] = backtest["trade_count"]
        record["total_ms"] = round(record["fixture_ms"] + record["feature_ms"] + record["fit_predict_ms"] + record["backtest_ms"], 2)
        records.append(record)

    df_records = pd.DataFrame(records)
    csv_path = output_dir / "benchmark_results.csv"
    json_path = output_dir / "benchmark_results.json"
    md_path = output_dir / "benchmark_results.md"
    df_records.to_csv(csv_path, index=False)
    payload = {
        "rows": rows,
        "repeats": repeats,
        "backend": backend,
        "horizon": horizon,
        "records": records,
        "mean_total_ms": round(float(df_records["total_ms"].mean()), 2),
        "p95_total_ms": round(float(df_records["total_ms"].quantile(0.95)), 2),
        "mean_feature_ms": round(float(df_records["feature_ms"].mean()), 2),
        "mean_fit_predict_ms": round(float(df_records["fit_predict_ms"].mean()), 2),
        "mean_backtest_ms": round(float(df_records["backtest_ms"].mean()), 2),
    }
    json_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    md = [
        "# Benchmark Results",
        "",
        f"- Backend: `{backend}`",
        f"- Rows: `{rows}`",
        f"- Repeats: `{repeats}`",
        f"- Mean total ms: `{payload['mean_total_ms']}`",
        f"- p95 total ms: `{payload['p95_total_ms']}`",
        "",
        df_records.to_markdown(index=False),
        "",
        "GPU benchmark must be rerun on the target RTX 4060 machine with `--backend cuda` after CUDA/XGBoost validation passes.",
    ]
    md_path.write_text("\n".join(md) + "\n", encoding="utf-8")
    payload["paths"] = {"csv": str(csv_path), "json": str(json_path), "md": str(md_path)}
    return payload
