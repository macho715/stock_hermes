# Technology Source URLs Checked

- TensorFlow pip install: https://www.tensorflow.org/install/pip
- TensorFlow source/install note: https://www.tensorflow.org/install/source_windows
- XGBoost GPU Support: https://xgboost.readthedocs.io/en/stable/gpu/
- XGBoost 3.2.0 Release Notes: https://xgboost.readthedocs.io/en/latest/changes/v3.2.0.html
- RAPIDS install docs: https://docs.rapids.ai/install/
- pandas 3.0.0 release notes: https://pandas.pydata.org/docs/dev/whatsnew/v3.0.0.html
- pandas PyArrow user guide: https://pandas.pydata.org/docs/user_guide/pyarrow.html
- pandas IO tools / CSV parser engines: https://pandas.pydata.org/docs/user_guide/io.html
- yfinance GitHub: https://github.com/ranaroussi/yfinance
- yfinance releases: https://github.com/ranaroussi/yfinance/releases
- vectorbt GitHub: https://github.com/polakowo/vectorbt
- Backtesting.py docs: https://kernc.github.io/backtesting.py/
- Backtesting.py API docs: https://kernc.github.io/backtesting.py/doc/backtesting/
