# 2026 Technical Cross-Check

## Uploaded-material alignment

| Uploaded requirement | Patch response |
|---|---|
| Windows i5-13500HX + RTX 4060 Laptop target, Track-S/Track-L/Risk Gate/GPU prediction/backtest/report output | Rebuilt as `stock_rtx4060` package with CLI entrypoint, hardware validation, Track-S and Track-L rule engines, backtester, report generator, and benchmark harness. |
| TensorFlow GPU risk on Windows native | Native Windows CUDA for modern TensorFlow is not assumed. WSL2/Linux path is documented; CPU fallback remains default. |
| UI/UX as report/table/journal outputs rather than a new web/mobile app | CLI creates Daily Brief, Risk Dashboard, Track-L Thesis, Monthly Scorecard, Journal CSV, and benchmark report. |

## 2026+ official technology basis

| Source | Observed technical point | Patch applied |
|---|---|---|
| TensorFlow install/source docs, 2026 | Modern TensorFlow CUDA on Windows requires WSL2/Linux path; native Windows GPU support is not assumed beyond old TF 2.10 line. | `hw_profile.configure_tensorflow()` blocks native-Windows CUDA assumptions and returns CPU fallback unless WSL2/Linux. |
| XGBoost GPU Support, 3.2 docs | GPU algorithms use CUDA with `device='cuda'`; CUDA 12.0 and Compute Capability 5.0+ are required. | `hw_profile.xgb_params()` emits `device='cuda'` + `tree_method='hist'`; `ensemble_model.py` catches CUDA failure and falls back to CPU. |
| XGBoost 3.2.0 release, 2026-02-09 | Enhanced GPU external memory support; async memory pool is Linux-only at release time. | Avoided hard dependency on external-memory CUDA paths; benchmark exposes `--prefer-gpu` and CPU fallback. |
| RAPIDS install docs | Windows RAPIDS path is WSL2 with NVIDIA drivers and supported Ubuntu environments. | RAPIDS/cuDF is not a hard dependency; WSL2 route is optional only. |
| pandas 3.0 docs | pandas 3.0 introduces default string dtype behavior and PyArrow-backed dtype/I/O options. | CSV loader attempts `engine='pyarrow'`/`dtype_backend='pyarrow'` when available, then falls back. |

## 2× GitHub repository cross-check

| Repo / project | What was checked | Adopted | Deferred |
|---|---|---|---|
| `dmlc/xgboost` / XGBoost docs | CUDA GPU interface, `device='cuda'`, `tree_method='hist'`, CPU-GPU model interoperability. | Optional CUDA XGBoost path and strict/soft fallback design. | Distributed/multi-GPU training and CUDA external-memory optimization. |
| `ranaroussi/yfinance` | Market data access API, research/education caveat, active 2026 issues/releases. | yfinance is optional; CSV/offline fixture remains first-class for reproducible runs. | Treating Yahoo data as production-grade guaranteed feed. |
| `polakowo/vectorbt` | Vectorized backtesting model using pandas/NumPy/Numba, large parameter sweeps. | Internal backtester keeps vectorized/low-dependency style where possible. | Full vectorbt dependency because Track-S rules require explicit Risk Gate traceability. |
| `kernc/backtesting.py` | Strategy viability backtesting, ML example, optimization/heatmap tutorials, AGPL license. | Backtest report includes trades, win rate, Sharpe, max drawdown, and historical-performance warning. | Direct dependency to avoid AGPL coupling and preserve simple project packaging. |

## Local benchmark policy

This execution environment has no NVIDIA GPU. The bundled benchmark is therefore an offline CPU smoke benchmark. On the target RTX 4060/WSL2 system, run:

```powershell
python main.py --benchmark --workspace .\workspace --benchmark-rows 1200
python main.py --benchmark --benchmark-model --prefer-gpu --workspace .\workspace --benchmark-rows 3000
```

Raw source URLs are in `docs/TECH_SOURCE_URLS.md`.
