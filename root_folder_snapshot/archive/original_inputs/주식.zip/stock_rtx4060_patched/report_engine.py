"""Markdown and CSV report generation for the investment OS."""
from __future__ import annotations

import csv
import json
from datetime import datetime
from pathlib import Path
from typing import Any

import pandas as pd


def _md_table(rows: list[dict[str, Any]], columns: list[str]) -> str:
    if not rows:
        rows = [{col: "-" for col in columns}]
    header = "| " + " | ".join(columns) + " |"
    sep = "|" + "|".join("---" for _ in columns) + "|"
    body = []
    for row in rows:
        body.append("| " + " | ".join(str(row.get(col, "")) for col in columns) + " |")
    return "\n".join([header, sep, *body])


def risk_verdict(*, score: float, rr: float, stop_pct: float, liquidity: bool, catalyst: bool, regime: bool) -> str:
    if stop_pct <= -20.0 or not liquidity:
        return "ZERO"
    if score >= 75.0 and rr >= 2.0 and abs(stop_pct) <= 4.0 and catalyst and regime:
        return "Watch/Buy"
    if score >= 65.0 and rr >= 1.5 and abs(stop_pct) <= 5.0:
        return "AMBER"
    return "No Trade"


def sample_short_rows(ticker: str, latest_close: float, probability: float, sector: str = "Model") -> list[dict[str, Any]]:
    score = round(float(probability) * 100.0, 2)
    entry = round(float(latest_close), 2)
    stop = round(entry * 0.96, 2)
    tp1 = round(entry * 1.05, 2)
    tp2 = round(entry * 1.10, 2)
    rr = (tp2 - entry) / max(entry - stop, 1e-9)
    verdict = risk_verdict(score=score, rr=rr, stop_pct=-4.0, liquidity=True, catalyst=score >= 70, regime=score >= 55)
    return [
        {
            "Ticker": ticker,
            "Sector": sector,
            "Score": f"{score:.2f}",
            "Entry": f"{entry:.2f}",
            "Stop": f"{stop:.2f}",
            "TP1": f"{tp1:.2f}",
            "TP2": f"{tp2:.2f}",
            "Risk": "-4.00%",
            "R/R": f"{rr:.2f}",
            "Verdict": verdict,
        }
    ]


def sample_long_rows() -> list[dict[str, Any]]:
    return [
        {
            "Ticker/ETF": "CORE-ETF",
            "Bucket": "Core Global",
            "Score": "85.00",
            "Target Weight": "40.00%",
            "Buy Rule": "월 DCA",
            "Exit Rule": "리밸런싱/Thesis 훼손",
            "Verdict": "Accumulate",
        },
        {
            "Ticker/ETF": "QUALITY",
            "Bucket": "Quality",
            "Score": "82.00",
            "Target Weight": "20.00%",
            "Buy Rule": "분할",
            "Exit Rule": "실적/재무 훼손",
            "Verdict": "Accumulate",
        },
        {
            "Ticker/ETF": "AI-INFRA",
            "Bucket": "AI/Infra",
            "Score": "80.00",
            "Target Weight": "15.00%",
            "Buy Rule": "조정 시 분할",
            "Exit Rule": "과열/Thesis 훼손",
            "Verdict": "AMBER",
        },
    ]


def write_reports(
    output_dir: Path,
    *,
    ticker: str,
    short_rows: list[dict[str, Any]],
    long_rows: list[dict[str, Any]],
    cv_summary: dict[str, Any],
    backtest: dict[str, Any],
    env_summary: dict[str, Any],
    benchmark: dict[str, Any] | None = None,
) -> dict[str, str]:
    output_dir.mkdir(parents=True, exist_ok=True)
    day = datetime.now().strftime("%Y-%m-%d")
    paths: dict[str, str] = {}

    daily = [
        f"# Daily Brief — {day}",
        "",
        "## Track-S 후보",
        _md_table(short_rows, ["Ticker", "Sector", "Score", "Entry", "Stop", "TP1", "TP2", "Risk", "R/R", "Verdict"]),
        "",
        "## Track-L 후보",
        _md_table(long_rows, ["Ticker/ETF", "Bucket", "Score", "Target Weight", "Buy Rule", "Exit Rule", "Verdict"]),
        "",
        "## Model CV Summary",
        "```json",
        json.dumps(cv_summary, ensure_ascii=False, indent=2),
        "```",
        "",
        "**주의:** 이 보고서는 자동매매/특정 종목 추천이 아니라 룰 기반 후보 평가와 사후 검토 산출물입니다.",
    ]
    daily_path = output_dir / f"daily_brief_{day}.md"
    daily_path.write_text("\n".join(daily) + "\n", encoding="utf-8")
    paths["daily_brief"] = str(daily_path)

    risk = [
        f"# Risk Dashboard — {day}",
        "",
        "| Metric | Value | Gate |",
        "|---|---:|---|",
        f"| Final Equity | {backtest['final_equity']} | Review |",
        f"| Total Return % | {backtest['total_return_pct']} | Info |",
        f"| Max Drawdown % | {backtest['max_drawdown_pct']} | AMBER if <= -12.00% |",
        f"| Open Risk % | {backtest['open_risk_pct']} | Green if <= 2.00% |",
        f"| Exposure % | {backtest['exposure_pct']} | Review |",
        f"| Trade Count | {backtest['trade_count']} | Info |",
        f"| Win Rate % | {backtest['win_rate_pct']} | Info |",
        "",
        "## Environment Gate",
        "```json",
        json.dumps(env_summary, ensure_ascii=False, indent=2),
        "```",
    ]
    risk_path = output_dir / f"risk_dashboard_{day}.md"
    risk_path.write_text("\n".join(risk) + "\n", encoding="utf-8")
    paths["risk_dashboard"] = str(risk_path)

    thesis = [
        f"# Track-L Thesis Report — {day}",
        "",
        _md_table(long_rows, ["Ticker/ETF", "Bucket", "Score", "Target Weight", "Buy Rule", "Exit Rule", "Verdict"]),
        "",
        "## Policy",
        "- Core 40.00%, Quality 20.00%, AI/Infra 15.00%, Commodity/Energy 10.00%, Bonds/Cash 15.00%",
        "- 신규 편입 후보는 Score ≥ 80.00 기준으로 검토합니다.",
        "- 단일 non-ETF 12.00% 초과 시 리밸런싱 검토 대상으로 표시합니다.",
    ]
    thesis_path = output_dir / f"track_l_thesis_{day}.md"
    thesis_path.write_text("\n".join(thesis) + "\n", encoding="utf-8")
    paths["track_l_thesis"] = str(thesis_path)

    monthly = [
        f"# Monthly Scorecard — {day}",
        "",
        "| KPI | Target | Actual | Status |",
        "|---|---:|---:|---|",
        f"| Track-S Monthly Return | +10.00% target, not guaranteed | {backtest['total_return_pct']}% | Review |",
        f"| Track-S Max Monthly Loss | -5.00% halt | {backtest['max_drawdown_pct']}% | {'RED' if backtest['max_drawdown_pct'] <= -5 else 'GREEN/AMBER'} |",
        "| Track-S Rule Violation | 0 | 0 | GREEN |",
        "| Track-L Max Single Name | ≤12.00% | N/A | Review |",
        "| Cash Buffer | ≥5.00% | N/A | Review |",
    ]
    monthly_path = output_dir / f"monthly_scorecard_{day}.md"
    monthly_path.write_text("\n".join(monthly) + "\n", encoding="utf-8")
    paths["monthly_scorecard"] = str(monthly_path)

    journal_path = output_dir / "track_s_journal.csv"
    exists = journal_path.exists()
    with journal_path.open("a", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=["timestamp", "ticker", "action", "reason", "rule_violation"])
        if not exists:
            writer.writeheader()
        writer.writerow(
            {
                "timestamp": datetime.now().isoformat(timespec="seconds"),
                "ticker": ticker,
                "action": "REPORT_ONLY",
                "reason": "No broker/order execution. Candidate scoring report generated.",
                "rule_violation": "False",
            }
        )
    paths["track_s_journal"] = str(journal_path)

    if benchmark:
        bench_path = output_dir / f"benchmark_summary_{day}.json"
        bench_path.write_text(json.dumps(benchmark, ensure_ascii=False, indent=2), encoding="utf-8")
        paths["benchmark_summary"] = str(bench_path)

    return paths
