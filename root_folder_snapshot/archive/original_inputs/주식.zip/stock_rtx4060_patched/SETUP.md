# SETUP — Windows i5-13500HX + RTX 4060 Laptop

## 1. Base CPU/offline setup

```powershell
winget install Python.Python.3.11
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python main.py --test
```

## 2. Environment validation

```powershell
nvidia-smi
python hw_profile.py
python main.py --benchmark --offline-fixture --rows 900 --repeats 3 --output-dir reports\benchmark
```

`environment_validation.md/json` must be saved before interpreting GPU benchmark numbers.

## 3. XGBoost CUDA path

XGBoost GPU path requires CUDA 12.0+ and sufficient compute capability. This patched script uses:

```python
XGBClassifier(tree_method="hist", device="cuda")
```

Run:

```powershell
python -m pip install -r requirements-gpu.txt
python main.py --backend cuda --strict-gpu --ticker AAPL --period 5y --output-dir reports\aapl_cuda
```

If the CUDA gate fails, run with `--backend sklearn` or `--backend xgboost-cpu`.

## 4. TensorFlow/LSTM path

TensorFlow is not enabled by default. For modern TensorFlow GPU on Windows, use WSL2. Windows Native GPU support ended after TensorFlow 2.10, so this project does not promise native Windows TensorFlow GPU execution.

## 5. Risk boundaries

- No broker API.
- No order execution.
- No margin/options/0DTE path.
- No recommendation engine. Reports are candidate/risk review artifacts only.
