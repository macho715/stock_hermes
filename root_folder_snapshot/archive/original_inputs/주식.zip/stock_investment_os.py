"""Backward-compatible entrypoint for the previous single-file script name."""

from stock_rtx4060.main import main

if __name__ == "__main__":
    raise SystemExit(main())
