"""Backtesting engine with Track-S risk controls."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any

import numpy as np
import pandas as pd


@dataclass(frozen=True)
class BacktestConfig:
    initial_capital: float = 100_000.0
    transaction_cost: float = 0.001
    slippage: float = 0.0005
    max_position_pct: float = 0.20
    risk_per_trade_pct: float = 0.0075
    threshold_buy: float = 0.58
    threshold_sell: float = 0.45
    stop_loss_pct: float = 0.04
    take_profit_pct: float = 0.10
    monthly_stop_pct: float = -0.05
    allow_short: bool = False


@dataclass(frozen=True)
class BacktestResult:
    total_return_pct: float
    annualized_return_pct: float
    sharpe_ratio: float
    max_drawdown_pct: float
    win_rate_pct: float
    n_trades: int
    final_capital: float
    monthly_stop_triggered: bool
    portfolio_values: list[float]
    trades: list[dict[str, Any]]
    config: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class Backtester:
    """Sequential long-only backtester with stops and monthly loss gate."""

    def __init__(self, config: BacktestConfig | None = None):
        self.config = config or BacktestConfig()

    def run(self, prices: pd.Series, signals: pd.Series) -> BacktestResult:
        prices = pd.Series(prices).dropna().astype(float)
        signals = pd.Series(signals).reindex(prices.index).ffill().fillna(0.5).astype(float)
        if len(prices) < 2:
            raise ValueError("at least two price observations are required")

        capital = float(self.config.initial_capital)
        position = 0.0
        entry_price = 0.0
        entry_idx: Any = None
        trades: list[dict[str, Any]] = []
        portfolio_values: list[float] = []
        monthly_stop_ever = False
        monthly_stop_active = False
        current_month = None
        month_start_value = capital

        for idx, price in prices.items():
            signal = float(signals.loc[idx])
            portfolio_value = capital + position * price
            portfolio_values.append(float(portfolio_value))

            month_key = _month_key(idx)
            if current_month != month_key:
                current_month = month_key
                month_start_value = portfolio_value
                monthly_stop_active = False
            month_return = (portfolio_value - month_start_value) / month_start_value if month_start_value else 0.0
            if month_return <= self.config.monthly_stop_pct:
                monthly_stop_active = True
                monthly_stop_ever = True

            if position > 0:
                pnl_pct = (price - entry_price) / entry_price
                exit_reason = None
                if pnl_pct <= -self.config.stop_loss_pct:
                    exit_reason = "stop_loss"
                elif pnl_pct >= self.config.take_profit_pct:
                    exit_reason = "take_profit"
                elif signal < self.config.threshold_sell:
                    exit_reason = "signal_reversal"
                elif monthly_stop_active:
                    exit_reason = "monthly_stop"
                if exit_reason:
                    gross = position * price
                    cost = gross * (self.config.transaction_cost + self.config.slippage)
                    capital += gross - cost
                    pnl = gross - cost - position * entry_price
                    trades.append({"entry_idx": str(entry_idx), "exit_idx": str(idx), "type": "SELL", "exit_reason": exit_reason, "price": float(price), "pnl": float(pnl), "pnl_pct": float(pnl_pct)})
                    position = 0.0
                    entry_price = 0.0
                    entry_idx = None

            if position == 0 and not monthly_stop_active and signal >= self.config.threshold_buy:
                stop_price = price * (1 - self.config.stop_loss_pct)
                risk_per_share = max(price - stop_price, 0.0)
                risk_budget = capital * self.config.risk_per_trade_pct
                max_position_value = capital * self.config.max_position_pct
                quantity = 0
                if risk_per_share > 0:
                    quantity = max(0, min(int(risk_budget // risk_per_share), int(max_position_value // price)))
                gross = quantity * price
                cost = gross * (self.config.transaction_cost + self.config.slippage)
                if quantity > 0 and gross + cost <= capital:
                    capital -= gross + cost
                    position = float(quantity)
                    entry_price = float(price)
                    entry_idx = idx
                    trades.append({"entry_idx": str(idx), "type": "BUY", "price": float(price), "quantity": quantity, "signal": signal, "stop": float(stop_price)})

        final_price = float(prices.iloc[-1])
        if position > 0:
            gross = position * final_price
            cost = gross * (self.config.transaction_cost + self.config.slippage)
            capital += gross - cost
            pnl = gross - cost - position * entry_price
            trades.append({"entry_idx": str(entry_idx), "exit_idx": str(prices.index[-1]), "type": "SELL", "exit_reason": "final_close", "price": final_price, "pnl": float(pnl), "pnl_pct": float((final_price - entry_price) / entry_price)})

        pv = pd.Series(portfolio_values, index=prices.index[: len(portfolio_values)]).astype(float)
        daily_returns = pv.pct_change().replace([np.inf, -np.inf], np.nan).dropna()
        total_return = (capital - self.config.initial_capital) / self.config.initial_capital
        annualized = (1 + total_return) ** (252 / max(1, len(prices))) - 1
        volatility = float(daily_returns.std())
        sharpe = float((daily_returns.mean() / volatility) * np.sqrt(252)) if volatility > 0 else 0.0
        mdd = max_drawdown(pv)
        closed = [trade for trade in trades if "pnl" in trade]
        wins = [trade for trade in closed if trade.get("pnl", 0.0) > 0]
        win_rate = len(wins) / len(closed) if closed else 0.0
        return BacktestResult(
            total_return_pct=round(total_return * 100, 4),
            annualized_return_pct=round(annualized * 100, 4),
            sharpe_ratio=round(sharpe, 4),
            max_drawdown_pct=round(mdd * 100, 4),
            win_rate_pct=round(win_rate * 100, 4),
            n_trades=len(closed),
            final_capital=round(float(capital), 2),
            monthly_stop_triggered=monthly_stop_ever,
            portfolio_values=[round(float(value), 4) for value in pv.to_list()],
            trades=trades,
            config=asdict(self.config),
        )


def max_drawdown(values: pd.Series) -> float:
    if values.empty:
        return 0.0
    peak = values.expanding().max()
    drawdown = (values - peak) / peak
    return abs(float(drawdown.min()))


def _month_key(index_value: Any) -> str:
    try:
        timestamp = pd.Timestamp(index_value)
        if not pd.isna(timestamp):
            return f"{timestamp.year:04d}-{timestamp.month:02d}"
    except Exception:
        pass
    return "static"
