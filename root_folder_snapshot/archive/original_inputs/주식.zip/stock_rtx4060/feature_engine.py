"""Feature engineering for OHLCV stock data.

The indicators are deterministic, vectorized with pandas/NumPy, and avoid
look-ahead leakage by only using future values for the target columns.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

import numpy as np
import pandas as pd

OHLCV_COLUMNS = ("Open", "High", "Low", "Close", "Volume")
TARGET_COLUMNS = ("target_direction", "target_return")


@dataclass(frozen=True)
class FeatureBuildResult:
    frame: pd.DataFrame
    feature_columns: list[str]
    target_columns: list[str]


def normalize_ohlcv(df: pd.DataFrame) -> pd.DataFrame:
    """Normalize common yfinance/CSV OHLCV variants to flat OHLCV columns."""

    if isinstance(df.columns, pd.MultiIndex):
        df = df.copy()
        df.columns = [str(col[0]) for col in df.columns]
    rename_map = {column.lower(): column for column in OHLCV_COLUMNS}
    normalized = df.rename(columns={col: rename_map.get(str(col).lower(), col) for col in df.columns})
    missing = set(OHLCV_COLUMNS) - set(normalized.columns)
    if missing:
        raise ValueError(f"required OHLCV columns missing: {sorted(missing)}")
    result = normalized.loc[:, list(OHLCV_COLUMNS)].copy()
    for column in OHLCV_COLUMNS:
        result[column] = pd.to_numeric(result[column], errors="coerce")
    result = result.dropna(subset=list(OHLCV_COLUMNS))
    result = result[result["Close"] > 0]
    result["Volume"] = result["Volume"].clip(lower=0)
    return result


def make_synthetic_ohlcv(n: int = 720, seed: int = 42) -> pd.DataFrame:
    """Generate deterministic synthetic OHLCV data for tests and benchmarks."""

    if n < 30:
        raise ValueError("n must be >= 30")
    rng = np.random.default_rng(seed)
    drift = 0.00025
    shocks = rng.normal(drift, 0.014, n)
    seasonal = 0.002 * np.sin(np.arange(n) / 21.0)
    close = 100 * np.cumprod(1 + shocks + seasonal)
    spread = rng.uniform(0.002, 0.022, n)
    high = close * (1 + spread)
    low = close * (1 - spread)
    open_ = low + rng.random(n) * (high - low)
    volume = rng.integers(700_000, 7_500_000, n).astype(float)
    index = pd.bdate_range("2022-01-03", periods=n)
    return pd.DataFrame(
        {"Open": open_, "High": high, "Low": low, "Close": close, "Volume": volume},
        index=index,
    )


class TechnicalIndicators:
    """Vectorized technical indicator builder."""

    def __init__(self, df: pd.DataFrame):
        self.df = normalize_ohlcv(df)

    def sma(self, period: int) -> pd.Series:
        return self.df["Close"].rolling(period, min_periods=period).mean()

    def ema(self, period: int) -> pd.Series:
        return self.df["Close"].ewm(span=period, adjust=False).mean()

    def macd(self) -> tuple[pd.Series, pd.Series, pd.Series]:
        fast = self.ema(12)
        slow = self.ema(26)
        line = fast - slow
        signal = line.ewm(span=9, adjust=False).mean()
        return line, signal, line - signal

    def adx(self, period: int = 14) -> pd.Series:
        high, low, close = self.df["High"], self.df["Low"], self.df["Close"]
        tr = pd.concat(
            [high - low, (high - close.shift(1)).abs(), (low - close.shift(1)).abs()],
            axis=1,
        ).max(axis=1)
        atr = tr.rolling(period, min_periods=period).mean()
        up_move = high.diff()
        down_move = -low.diff()
        dm_plus = up_move.where((up_move > down_move) & (up_move > 0), 0.0)
        dm_minus = down_move.where((down_move > up_move) & (down_move > 0), 0.0)
        di_plus = 100 * dm_plus.rolling(period, min_periods=period).mean() / atr
        di_minus = 100 * dm_minus.rolling(period, min_periods=period).mean() / atr
        dx = 100 * (di_plus - di_minus).abs() / (di_plus + di_minus)
        return dx.rolling(period, min_periods=period).mean()

    def rsi(self, period: int = 14) -> pd.Series:
        delta = self.df["Close"].diff()
        gain = delta.clip(lower=0).rolling(period, min_periods=period).mean()
        loss = (-delta.clip(upper=0)).rolling(period, min_periods=period).mean()
        rs = gain / loss.replace(0, np.nan)
        return 100 - (100 / (1 + rs))

    def stochastic(self, k: int = 14, d: int = 3) -> tuple[pd.Series, pd.Series]:
        low_min = self.df["Low"].rolling(k, min_periods=k).min()
        high_max = self.df["High"].rolling(k, min_periods=k).max()
        pct_k = 100 * (self.df["Close"] - low_min) / (high_max - low_min)
        pct_d = pct_k.rolling(d, min_periods=d).mean()
        return pct_k, pct_d

    def williams_r(self, period: int = 14) -> pd.Series:
        high_max = self.df["High"].rolling(period, min_periods=period).max()
        low_min = self.df["Low"].rolling(period, min_periods=period).min()
        return -100 * (high_max - self.df["Close"]) / (high_max - low_min)

    def cci(self, period: int = 20) -> pd.Series:
        typical = (self.df["High"] + self.df["Low"] + self.df["Close"]) / 3
        mean = typical.rolling(period, min_periods=period).mean()
        mad = typical.rolling(period, min_periods=period).apply(
            lambda values: float(np.mean(np.abs(values - values.mean()))),
            raw=False,
        )
        return (typical - mean) / (0.015 * mad)

    def roc(self, period: int = 10) -> pd.Series:
        return self.df["Close"].pct_change(period) * 100

    def bollinger_bands(self, period: int = 20, k: float = 2.0) -> tuple[pd.Series, ...]:
        mid = self.sma(period)
        std = self.df["Close"].rolling(period, min_periods=period).std()
        upper = mid + k * std
        lower = mid - k * std
        bandwidth = (upper - lower) / mid
        pct_b = (self.df["Close"] - lower) / (upper - lower)
        return upper, mid, lower, bandwidth, pct_b

    def atr(self, period: int = 14) -> pd.Series:
        high, low, close = self.df["High"], self.df["Low"], self.df["Close"]
        tr = pd.concat(
            [high - low, (high - close.shift(1)).abs(), (low - close.shift(1)).abs()],
            axis=1,
        ).max(axis=1)
        return tr.rolling(period, min_periods=period).mean()

    def historical_volatility(self, period: int = 20) -> pd.Series:
        log_return = np.log(self.df["Close"] / self.df["Close"].shift(1))
        return log_return.rolling(period, min_periods=period).std() * np.sqrt(252)

    def obv(self) -> pd.Series:
        direction = np.sign(self.df["Close"].diff()).fillna(0)
        return (direction * self.df["Volume"]).cumsum()

    def vwap(self, period: int = 20) -> pd.Series:
        typical = (self.df["High"] + self.df["Low"] + self.df["Close"]) / 3
        dollar_volume = typical * self.df["Volume"]
        return dollar_volume.rolling(period, min_periods=period).sum() / self.df[
            "Volume"
        ].rolling(period, min_periods=period).sum()

    def mfi(self, period: int = 14) -> pd.Series:
        typical = (self.df["High"] + self.df["Low"] + self.df["Close"]) / 3
        money_flow = typical * self.df["Volume"]
        positive = money_flow.where(typical > typical.shift(1), 0).rolling(period).sum()
        negative = money_flow.where(typical < typical.shift(1), 0).rolling(period).sum()
        mfr = positive / negative.replace(0, np.nan)
        return 100 - (100 / (1 + mfr))

    def build_all(self, horizon: int = 5, dropna: bool = True) -> pd.DataFrame:
        if horizon <= 0:
            raise ValueError("horizon must be positive")
        f = self.df.copy()
        close = f["Close"]

        f["return_1d"] = close.pct_change(1)
        f["return_3d"] = close.pct_change(3)
        f["return_5d"] = close.pct_change(5)
        f["return_20d"] = close.pct_change(20)
        f["overnight_gap"] = f["Open"] / close.shift(1) - 1
        f["intraday_return"] = close / f["Open"] - 1
        f["range_pct"] = (f["High"] - f["Low"]) / close

        for period in (5, 10, 20, 50, 100, 200):
            f[f"sma_{period}"] = self.sma(period)
            f[f"sma_ratio_{period}"] = close / f[f"sma_{period}"] - 1
        for period in (9, 21, 50):
            f[f"ema_{period}"] = self.ema(period)
            f[f"ema_ratio_{period}"] = close / f[f"ema_{period}"] - 1

        f["macd"], f["macd_signal"], f["macd_hist"] = self.macd()
        f["adx_14"] = self.adx()
        f["rsi_7"] = self.rsi(7)
        f["rsi_14"] = self.rsi(14)
        f["stoch_k"], f["stoch_d"] = self.stochastic()
        f["williams_r"] = self.williams_r()
        f["cci_20"] = self.cci()
        f["roc_10"] = self.roc()
        (
            f["bb_upper"],
            f["bb_mid"],
            f["bb_lower"],
            f["bb_width"],
            f["bb_pct"],
        ) = self.bollinger_bands()
        f["atr_14"] = self.atr()
        f["atr_pct"] = f["atr_14"] / close
        f["hist_vol_20"] = self.historical_volatility()
        f["obv"] = self.obv()
        f["vwap_ratio"] = close / self.vwap() - 1
        f["mfi_14"] = self.mfi()
        f["volume_ratio_20"] = f["Volume"] / f["Volume"].rolling(20).mean()
        f["dollar_volume"] = close * f["Volume"]
        f["liquidity_score"] = np.log1p(f["dollar_volume"])

        future_return = close.shift(-horizon) / close - 1
        f["target_direction"] = (future_return > 0).astype(int)
        f["target_return"] = future_return

        raw_cols = list(OHLCV_COLUMNS) + [
            "sma_5",
            "sma_10",
            "sma_20",
            "sma_50",
            "sma_100",
            "sma_200",
            "ema_9",
            "ema_21",
            "ema_50",
            "bb_upper",
            "bb_mid",
            "bb_lower",
        ]
        f = f.drop(columns=[col for col in raw_cols if col in f.columns])
        f = f.replace([np.inf, -np.inf], np.nan)
        if dropna:
            f = f.dropna()
        return f


def build_feature_frame(df: pd.DataFrame, horizon: int = 5) -> FeatureBuildResult:
    frame = TechnicalIndicators(df).build_all(horizon=horizon)
    feature_columns = [col for col in frame.columns if col not in TARGET_COLUMNS]
    return FeatureBuildResult(frame=frame, feature_columns=feature_columns, target_columns=list(TARGET_COLUMNS))


def align_feature_columns(frame: pd.DataFrame, columns: Iterable[str]) -> pd.DataFrame:
    result = frame.copy()
    for column in columns:
        if column not in result:
            result[column] = 0.0
    return result.loc[:, list(columns)].fillna(0.0)
