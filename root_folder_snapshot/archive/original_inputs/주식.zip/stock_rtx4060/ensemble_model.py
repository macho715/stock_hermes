"""Optional XGBoost + optional LSTM ensemble with deterministic CPU fallback."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import numpy as np
import pandas as pd

from .hw_profile import xgb_params


@dataclass(frozen=True)
class ModelConfig:
    horizon: int = 5
    seq_len: int = 20
    n_splits: int = 5
    prefer_gpu: bool = False
    use_xgboost: bool = False
    lite: bool = False
    use_lstm: bool = False
    xgb_weight: float = 0.70
    lstm_weight: float = 0.30
    random_state: int = 42
    xgb_params: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class FoldMetric:
    fold: int
    backend: str
    accuracy: float
    auc: float | None
    n_train: int
    n_test: int


class Standardizer:
    def __init__(self) -> None:
        self.mean_: np.ndarray | None = None
        self.scale_: np.ndarray | None = None

    def fit(self, X: np.ndarray) -> "Standardizer":
        self.mean_ = np.nanmean(X, axis=0)
        self.scale_ = np.nanstd(X, axis=0)
        self.scale_ = np.where(self.scale_ == 0, 1.0, self.scale_)
        return self

    def transform(self, X: np.ndarray) -> np.ndarray:
        if self.mean_ is None or self.scale_ is None:
            raise RuntimeError("Standardizer.fit must be called first")
        return np.nan_to_num((X - self.mean_) / self.scale_, nan=0.0, posinf=0.0, neginf=0.0)

    def fit_transform(self, X: np.ndarray) -> np.ndarray:
        return self.fit(X).transform(X)


class NumpyLogisticClassifier:
    def __init__(self, learning_rate: float = 0.08, epochs: int = 240, l2: float = 0.001) -> None:
        self.learning_rate = learning_rate
        self.epochs = epochs
        self.l2 = l2
        self.scaler = Standardizer()
        self.weights: np.ndarray | None = None
        self.bias = 0.0

    def fit(self, X_df: pd.DataFrame, y: pd.Series) -> "NumpyLogisticClassifier":
        X = self.scaler.fit_transform(X_df.to_numpy(dtype=float))
        y_arr = y.to_numpy(dtype=float)
        n_features = X.shape[1]
        rng = np.random.default_rng(42)
        self.weights = rng.normal(0.0, 0.01, n_features)
        self.bias = 0.0
        for _ in range(self.epochs):
            logits = X @ self.weights + self.bias
            proba = _sigmoid(logits)
            error = proba - y_arr
            grad_w = (X.T @ error) / len(X) + self.l2 * self.weights
            grad_b = float(np.mean(error))
            self.weights -= self.learning_rate * grad_w
            self.bias -= self.learning_rate * grad_b
        return self

    def predict_proba(self, X_df: pd.DataFrame) -> np.ndarray:
        if self.weights is None:
            raise RuntimeError("model is not fitted")
        X = self.scaler.transform(X_df.to_numpy(dtype=float))
        return _sigmoid(X @ self.weights + self.bias)


class XGBOrFallbackPredictor:
    def __init__(self, config: ModelConfig) -> None:
        self.config = config
        self.backend = "numpy-logistic"
        self.feature_cols: list[str] = []
        self.model: Any = NumpyLogisticClassifier(epochs=120 if config.lite else 240)

    def fit(self, X: pd.DataFrame, y: pd.Series) -> "XGBOrFallbackPredictor":
        self.feature_cols = list(X.columns)
        params = self.config.xgb_params or xgb_params(prefer_gpu=self.config.prefer_gpu, lite=self.config.lite, random_state=self.config.random_state)
        if not (self.config.use_xgboost or self.config.prefer_gpu):
            self.model = NumpyLogisticClassifier(epochs=120 if self.config.lite else 240)
            self.model.fit(X[self.feature_cols], y)
            self.backend = "numpy-logistic"
            return self
        try:
            from xgboost import XGBClassifier  # type: ignore
            self.model = XGBClassifier(**params)
            self.model.fit(X[self.feature_cols], y)
            self.backend = f"xgboost-{params.get('device', 'cpu')}"
        except Exception as exc:
            self.model = NumpyLogisticClassifier(epochs=120 if self.config.lite else 240)
            self.model.fit(X[self.feature_cols], y)
            self.backend = f"numpy-logistic-fallback ({type(exc).__name__})"
        return self

    def predict_proba(self, X: pd.DataFrame) -> np.ndarray:
        X_aligned = X.reindex(columns=self.feature_cols).fillna(0.0)
        if hasattr(self.model, "predict_proba") and self.backend.startswith("xgboost"):
            proba = self.model.predict_proba(X_aligned)
            return np.asarray(proba)[:, 1]
        return np.asarray(self.model.predict_proba(X_aligned))


class LSTMPredictor:
    def __init__(self, config: ModelConfig) -> None:
        self.config = config
        self.model: Any = None
        self.scaler = Standardizer()
        self.available = False

    def fit(self, X: pd.DataFrame, y: pd.Series) -> "LSTMPredictor":
        try:
            from tensorflow.keras.callbacks import EarlyStopping  # type: ignore
            from tensorflow.keras.layers import LSTM, Dense, Dropout, Input  # type: ignore
            from tensorflow.keras.models import Sequential  # type: ignore
            from tensorflow.keras.optimizers import Adam  # type: ignore
        except Exception as exc:
            raise RuntimeError(f"TensorFlow unavailable: {exc}") from exc
        X_scaled = self.scaler.fit_transform(X.to_numpy(dtype=float))
        X_seq, y_seq = _build_sequences(X_scaled, y.to_numpy(dtype=float), self.config.seq_len)
        if len(X_seq) < 16:
            raise RuntimeError("not enough rows for LSTM sequence training")
        try:
            from tensorflow.keras import mixed_precision  # type: ignore
            mixed_precision.set_global_policy("mixed_float16")
        except Exception:
            pass
        units1 = 32 if self.config.lite else 64
        units2 = 16 if self.config.lite else 32
        self.model = Sequential([
            Input(shape=(self.config.seq_len, X.shape[1])),
            LSTM(units1, return_sequences=True),
            Dropout(0.25),
            LSTM(units2),
            Dense(16, activation="relu"),
            Dense(1, activation="sigmoid", dtype="float32"),
        ])
        self.model.compile(optimizer=Adam(learning_rate=0.001), loss="binary_crossentropy", metrics=["accuracy"])
        self.model.fit(X_seq, y_seq, epochs=8 if self.config.lite else 20, batch_size=32 if self.config.lite else 64, validation_split=0.1, callbacks=[EarlyStopping(patience=3, restore_best_weights=True)], verbose=0)
        self.available = True
        return self

    def predict_proba(self, X: pd.DataFrame) -> np.ndarray:
        if not self.available or self.model is None:
            raise RuntimeError("LSTM not fitted")
        X_scaled = self.scaler.transform(X.to_numpy(dtype=float))
        X_seq, _ = _build_sequences(X_scaled, np.zeros(len(X_scaled)), self.config.seq_len)
        if len(X_seq) == 0:
            return np.array([])
        return self.model.predict(X_seq, verbose=0).flatten()


class EnsemblePredictor:
    def __init__(self, config: ModelConfig | None = None) -> None:
        self.config = config or ModelConfig()
        self.xgb = XGBOrFallbackPredictor(self.config)
        self.lstm: LSTMPredictor | None = None
        self.feature_cols: list[str] = []
        self.metrics: list[FoldMetric] = []
        self.trained = False

    def fit(self, feature_df: pd.DataFrame) -> list[dict[str, Any]]:
        X, y = _split_xy(feature_df)
        self.feature_cols = list(X.columns)
        self.metrics = []
        for fold, (train_idx, test_idx) in enumerate(walk_forward_splits(len(X), self.config.n_splits), start=1):
            model = XGBOrFallbackPredictor(self.config)
            model.fit(X.iloc[train_idx], y.iloc[train_idx])
            prob = model.predict_proba(X.iloc[test_idx])
            metric = FoldMetric(
                fold=fold,
                backend=model.backend,
                accuracy=round(accuracy_score_np(y.iloc[test_idx].to_numpy(), prob), 6),
                auc=roc_auc_np(y.iloc[test_idx].to_numpy(), prob),
                n_train=len(train_idx),
                n_test=len(test_idx),
            )
            self.metrics.append(metric)
        self.xgb.fit(X, y)
        if self.config.use_lstm:
            try:
                self.lstm = LSTMPredictor(self.config).fit(X, y)
            except Exception:
                self.lstm = None
        self.trained = True
        return [metric.__dict__ for metric in self.metrics]

    def predict_proba(self, X: pd.DataFrame) -> np.ndarray:
        if not self.trained:
            raise RuntimeError("fit() must be called before predict")
        X_aligned = X.reindex(columns=self.feature_cols).fillna(0.0)
        xgb_prob = self.xgb.predict_proba(X_aligned)
        if self.lstm is None:
            return xgb_prob
        try:
            lstm_prob = self.lstm.predict_proba(X_aligned)
        except Exception:
            return xgb_prob
        if len(lstm_prob) == 0:
            return xgb_prob
        result = xgb_prob.copy()
        offset = len(result) - len(lstm_prob)
        result[offset:] = self.config.xgb_weight * xgb_prob[offset:] + self.config.lstm_weight * lstm_prob
        return result

    def predict_latest(self, feature_df: pd.DataFrame) -> dict[str, Any]:
        X, _ = _split_xy(feature_df, require_target=False)
        probabilities = self.predict_proba(X)
        latest = float(probabilities[-1])
        confidence = abs(latest - 0.5) * 2
        signal = "BUY" if latest >= 0.58 else ("SELL" if latest <= 0.45 else "HOLD")
        return {"direction_prob": round(latest, 6), "signal": signal, "confidence": round(float(confidence), 6), "backend": self.xgb.backend, "lstm_enabled": self.lstm is not None}


def walk_forward_splits(n_rows: int, n_splits: int) -> list[tuple[np.ndarray, np.ndarray]]:
    if n_rows < 40:
        raise ValueError("at least 40 rows are required for walk-forward validation")
    n_splits = max(2, min(n_splits, max(2, n_rows // 40)))
    test_size = max(10, n_rows // (n_splits + 1))
    splits: list[tuple[np.ndarray, np.ndarray]] = []
    for fold in range(n_splits):
        test_start = n_rows - (n_splits - fold) * test_size
        test_end = min(n_rows, test_start + test_size)
        if test_start <= 10 or test_end <= test_start:
            continue
        splits.append((np.arange(0, test_start), np.arange(test_start, test_end)))
    if not splits:
        midpoint = n_rows // 2
        splits.append((np.arange(0, midpoint), np.arange(midpoint, n_rows)))
    return splits


def accuracy_score_np(y_true: np.ndarray, prob: np.ndarray, threshold: float = 0.5) -> float:
    pred = (prob >= threshold).astype(int)
    return float(np.mean(pred == y_true.astype(int)))


def roc_auc_np(y_true: np.ndarray, prob: np.ndarray) -> float | None:
    y = y_true.astype(int)
    pos = prob[y == 1]
    neg = prob[y == 0]
    if len(pos) == 0 or len(neg) == 0:
        return None
    comparisons = (pos[:, None] > neg[None, :]).mean()
    ties = 0.5 * (pos[:, None] == neg[None, :]).mean()
    return round(float(comparisons + ties), 6)


def _split_xy(feature_df: pd.DataFrame, require_target: bool = True) -> tuple[pd.DataFrame, pd.Series]:
    target_cols = ["target_direction", "target_return"]
    feature_cols = [col for col in feature_df.columns if col not in target_cols]
    if require_target and "target_direction" not in feature_df:
        raise ValueError("feature_df must include target_direction")
    X = feature_df[feature_cols].astype(float).fillna(0.0)
    y = feature_df.get("target_direction", pd.Series(np.zeros(len(feature_df)), index=feature_df.index)).astype(int)
    return X, y


def _build_sequences(X: np.ndarray, y: np.ndarray, seq_len: int) -> tuple[np.ndarray, np.ndarray]:
    if len(X) <= seq_len:
        return np.empty((0, seq_len, X.shape[1])), np.empty((0,))
    X_seq = [X[i - seq_len : i] for i in range(seq_len, len(X))]
    y_seq = y[seq_len:]
    return np.asarray(X_seq), np.asarray(y_seq)


def _sigmoid(values: np.ndarray) -> np.ndarray:
    values = np.clip(values, -35, 35)
    return 1.0 / (1.0 + np.exp(-values))
