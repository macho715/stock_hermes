"""Compatibility wrapper. Use stock_rtx4060.hw_profile instead."""
from stock_rtx4060.hw_profile import *  # noqa: F401,F403
