# Monthly Scorecard

Generated: 2026-05-02T09:43:09

## Track-S Performance

| Metric           |   Value |
|:-----------------|--------:|
| total_return_pct |  6.9866 |
| sharpe_ratio     |  1.2755 |
| max_drawdown_pct |  1.7895 |
| win_rate_pct     | 70.8333 |
| n_trades         | 24      |

## Rule Violations

- None recorded.

## Review Actions

- If Track-S reaches +10.00% monthly target gate, reduce trading intensity.
- If Track-S reaches -5.00% monthly loss gate, stop new Track-S trades for the month.
- Track-L: DCA/rebalance only after thesis review and bucket drift check.
